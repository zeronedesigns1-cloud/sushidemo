import React, { useState } from 'react';
import { Appointment, CartItem, Pet, Product, ScreenType, TabType } from './types';
import { DOCTORS, INITIAL_PETS, INITIAL_PRODUCTS } from './data/mockData';
import { Header } from './components/Header';
import { BottomNav } from './components/BottomNav';
import { PetDetailModal } from './components/PetDetailModal';
import { CartDrawer } from './components/CartDrawer';
import { BookingSuccessModal } from './components/BookingSuccessModal';
import { HomeScreen } from './views/HomeScreen';
import { MarketplaceScreen } from './views/MarketplaceScreen';
import { ShopScreen } from './views/ShopScreen';
import { VetCareScreen } from './views/VetCareScreen';
import { ListingFormScreen } from './views/ListingFormScreen';
import { CameraHudScreen } from './views/CameraHudScreen';
import { ProfileModal } from './views/ProfileModal';
import { NotificationsModal } from './views/NotificationsModal';

export default function App() {
  const [currentTab, setCurrentTab] = useState<TabType>('home');
  const [activeScreen, setActiveScreen] = useState<ScreenType>('home');
  const [pets, setPets] = useState<Pet[]>(INITIAL_PETS);
  const [products] = useState<Product[]>(INITIAL_PRODUCTS);
  const [cart, setCart] = useState<CartItem[]>([
    { product: INITIAL_PRODUCTS[0], quantity: 1 },
    { product: INITIAL_PRODUCTS[1], quantity: 1 },
  ]);
  const [favorites, setFavorites] = useState<string[]>(['pet-1', 'pet-2']);
  const [selectedPet, setSelectedPet] = useState<Pet | null>(null);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isProfileOpen, setIsProfileOpen] = useState(false);
  const [isNotificationsOpen, setIsNotificationsOpen] = useState(false);
  const [confirmedAppointment, setConfirmedAppointment] = useState<Appointment | null>(null);
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [anglePhotos, setAnglePhotos] = useState<Record<string, string>>({
    front: 'https://lh3.googleusercontent.com/aida-public/AB6AXuBen7lAilvcWCHahZMKfed7PYUhDIpZJ0qGjt7nytgBGdQRUdrkcgyhgOpEDc7Oe8Aix9s-WzqaSo3DkT7_ZEirIMN1X_GPrHCjnQctVABHHg3mf1HsUpffF3f1K83DYjacPNw2JoXnXTntJe8Vtv2P-mvfwas99GKK1pjUZaHFqUS-QYf9J3Wf2krxG1jRz0NraEVh2kJ3Qco7cjFi-hhpL3S9RxaLi3vieD6NWkgxjqkQzeONq2A1',
  });
  const [activeAngleIndex, setActiveAngleIndex] = useState(0);
  const [isFramed, setIsFramed] = useState(true);

  // Cart operations
  const handleAddToCart = (product: Product) => {
    setCart((prev) => {
      const existing = prev.find((item) => item.product.id === product.id);
      if (existing) {
        return prev.map((item) =>
          item.product.id === product.id
            ? { ...item, quantity: item.quantity + 1 }
            : item
        );
      }
      return [...prev, { product, quantity: 1 }];
    });
  };

  const handleUpdateQuantity = (productId: string, delta: number) => {
    setCart((prev) =>
      prev
        .map((item) => {
          if (item.product.id === productId) {
            const newQty = item.quantity + delta;
            return newQty > 0 ? { ...item, quantity: newQty } : null;
          }
          return item;
        })
        .filter(Boolean) as CartItem[]
    );
  };

  const handleClearCart = () => {
    setCart([]);
  };

  const totalCartCount = cart.reduce((acc, item) => acc + item.quantity, 0);

  // Favorite toggle
  const handleToggleFavorite = (petId: string) => {
    setFavorites((prev) =>
      prev.includes(petId) ? prev.filter((id) => id !== petId) : [...prev, petId]
    );
  };

  // Tab switching
  const handleTabChange = (tab: TabType) => {
    setCurrentTab(tab);
    setActiveScreen(tab);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Appointment booked
  const handleAppointmentBooked = (appointment: Appointment) => {
    setAppointments((prev) => [appointment, ...prev]);
    setConfirmedAppointment(appointment);
  };

  // Publish new listing
  const handlePublishPet = (newPet: Pet) => {
    setPets((prev) => [newPet, ...prev]);
    setActiveScreen('marketplace');
    setCurrentTab('marketplace');
    setSelectedPet(newPet);
  };

  // Photo capture in Camera HUD
  const handlePhotoCaptured = (angleKey: 'front' | 'left' | 'right' | 'paw', photoUrl: string) => {
    setAnglePhotos((prev) => ({
      ...prev,
      [angleKey]: photoUrl,
    }));
  };

  const handleOpenCameraHud = (angleKey: 'front' | 'left' | 'right' | 'paw') => {
    setActiveScreen('camera-hud');
  };

  // Render current active screen
  const renderScreen = () => {
    switch (activeScreen) {
      case 'camera-hud':
        return (
          <CameraHudScreen
            onBack={() => setActiveScreen('listing-form')}
            onPhotoCaptured={handlePhotoCaptured}
            currentAngleIndex={activeAngleIndex}
          />
        );
      case 'listing-form':
        return (
          <ListingFormScreen
            onBack={() => {
              setActiveScreen(currentTab);
            }}
            onOpenCameraHud={handleOpenCameraHud}
            onPublishPet={handlePublishPet}
            anglePhotos={anglePhotos}
          />
        );
      case 'marketplace':
        return (
          <MarketplaceScreen
            pets={pets}
            onSelectPet={(pet) => setSelectedPet(pet)}
            favorites={favorites}
            onToggleFavorite={handleToggleFavorite}
            onOpenListingForm={() => setActiveScreen('listing-form')}
          />
        );
      case 'shop':
        return (
          <ShopScreen
            products={products}
            onAddToCart={handleAddToCart}
            cartCount={totalCartCount}
            onOpenCart={() => setIsCartOpen(true)}
          />
        );
      case 'vetcare':
        return (
          <VetCareScreen
            doctors={DOCTORS}
            onAppointmentBooked={handleAppointmentBooked}
          />
        );
      case 'home':
      default:
        return (
          <HomeScreen
            onNavigate={handleTabChange}
            featuredPets={pets.slice(0, 5)}
            onSelectPet={(pet) => setSelectedPet(pet)}
            favorites={favorites}
            onToggleFavorite={handleToggleFavorite}
            onOpenListingForm={() => setActiveScreen('listing-form')}
          />
        );
    }
  };

  const isFullscreenView = activeScreen === 'camera-hud';
  const showNav = !isFullscreenView && activeScreen !== 'listing-form';

  return (
    <div className="min-h-screen bg-slate-900 flex justify-center items-center font-sans antialiased">
      {/* Container: If framed on desktop, it renders in an elegant mobile frame shell */}
      <div
        className={`w-full min-h-screen transition-all duration-300 relative bg-[#faf8ff] text-[#131b2e] flex flex-col ${
          isFramed
            ? 'max-w-[430px] my-0 md:my-6 md:rounded-[44px] md:shadow-[0_25px_70px_rgba(0,0,0,0.6)] md:border-[8px] md:border-slate-800 md:min-h-[884px] md:max-h-[92vh] overflow-y-auto no-scrollbar ring-1 ring-white/10'
            : 'max-w-2xl shadow-xl'
        }`}
      >
        {/* Top Status Bar indicator simulation for framed mobile look */}
        {isFramed && (
          <div className="hidden md:flex items-center justify-between px-7 pt-3 pb-1 text-slate-800 text-[11px] font-bold z-50 bg-[#ffffff]/90 select-none">
            <span>09:41</span>
            <div className="w-20 h-4 bg-slate-900 rounded-full mx-auto" />
            <div className="flex items-center gap-1.5 text-xs">
              <span className="material-symbols-outlined text-[14px]">signal_cellular_alt</span>
              <span className="material-symbols-outlined text-[14px]">wifi</span>
              <span className="material-symbols-outlined text-[14px]">battery_full</span>
            </div>
          </div>
        )}

        {/* Global Header (shown except in Camera HUD and Listing Form) */}
        {!isFullscreenView && activeScreen !== 'listing-form' && (
          <Header
            currentTab={currentTab}
            cartCount={totalCartCount}
            onOpenCart={() => setIsCartOpen(true)}
            onOpenProfile={() => setIsProfileOpen(true)}
            onOpenNotifications={() => setIsNotificationsOpen(true)}
            isFramed={isFramed}
            onToggleFrame={() => setIsFramed(!isFramed)}
          />
        )}

        {/* Main Content Area */}
        <main className="flex-1 w-full flex flex-col relative">{renderScreen()}</main>

        {/* Bottom Nav Bar */}
        {showNav && (
          <BottomNav
            currentTab={currentTab}
            onChangeTab={handleTabChange}
            cartCount={totalCartCount}
          />
        )}

        {/* Modals & Slide-overs */}
        <PetDetailModal
          pet={selectedPet}
          onClose={() => setSelectedPet(null)}
          isFavorite={selectedPet ? favorites.includes(selectedPet.id) : false}
          onToggleFavorite={handleToggleFavorite}
          onBookVetVisit={() => {
            setSelectedPet(null);
            handleTabChange('vetcare');
          }}
        />

        <CartDrawer
          isOpen={isCartOpen}
          onClose={() => setIsCartOpen(false)}
          cart={cart}
          onUpdateQuantity={handleUpdateQuantity}
          onClearCart={handleClearCart}
        />

        <BookingSuccessModal
          appointment={confirmedAppointment}
          onClose={() => setConfirmedAppointment(null)}
        />

        <ProfileModal
          isOpen={isProfileOpen}
          onClose={() => setIsProfileOpen(false)}
          appointments={appointments}
        />

        <NotificationsModal
          isOpen={isNotificationsOpen}
          onClose={() => setIsNotificationsOpen(false)}
          onNavigateToVet={() => handleTabChange('vetcare')}
          onNavigateToShop={() => handleTabChange('shop')}
        />
      </div>
    </div>
  );
}
