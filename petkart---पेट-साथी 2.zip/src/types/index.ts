export type TabType = 'home' | 'marketplace' | 'shop' | 'vetcare';

export type ScreenType = TabType | 'listing-form' | 'camera-hud';

export interface Pet {
  id: string;
  name: string;
  nameMr: string;
  category: 'dogs' | 'cats' | 'puppies' | 'kittens' | 'birds' | 'other';
  breed: string;
  breedMr: string;
  age: string;
  ageMr: string;
  gender: 'Male' | 'Female';
  genderMr: string;
  location: string;
  localityMr: string;
  price: number; // 0 for free adoption
  isAdoption: boolean;
  images: string[];
  badges: string[];
  description: string;
  descriptionMr: string;
  sellerName: string;
  sellerPhone: string;
  isVaccinated: boolean;
  isDewormed: boolean;
  isKciRegistered: boolean;
  rating?: number;
}

export interface Product {
  id: string;
  name: string;
  nameMr: string;
  category: 'food' | 'toys' | 'hygiene' | 'meds';
  weight: string;
  weightMr: string;
  price: number;
  originalPrice?: number;
  discountBadge?: string;
  rating: number;
  reviewsCount: number;
  image: string;
  inStock: boolean;
  description?: string;
}

export interface CartItem {
  product: Product;
  quantity: number;
}

export interface Doctor {
  id: string;
  name: string;
  nameMr: string;
  qualification: string;
  experience: string;
  rating: number;
  reviewsCount: number;
  locality: string;
  distance: string;
  clinicFee: number;
  homeVisitFee: number;
  image: string;
  availableDays: string[];
}

export interface Appointment {
  id: string;
  doctorId: string;
  doctorName: string;
  petType: string;
  petName?: string;
  date: string;
  timeSlot: string;
  visitType: 'clinic' | 'home';
  fee: number;
  status: 'confirmed' | 'pending' | 'completed';
  timestamp: string;
}

export interface AnglePhoto {
  angleKey: 'front' | 'left' | 'right' | 'paw';
  title: string;
  titleMr: string;
  mandatory: boolean;
  uploaded: boolean;
  previewUrl?: string;
}
