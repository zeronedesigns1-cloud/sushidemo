import React from 'react';
import { Appointment } from '../types';

interface BookingSuccessModalProps {
  appointment: Appointment | null;
  onClose: () => void;
}

export const BookingSuccessModal: React.FC<BookingSuccessModalProps> = ({
  appointment,
  onClose,
}) => {
  if (!appointment) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 animate-in fade-in duration-200">
      <div className="bg-white w-full max-w-sm rounded-3xl p-5 shadow-2xl text-center space-y-4">
        {/* Animated Checkmark */}
        <div className="w-16 h-16 rounded-full bg-emerald-100 text-[#006c4a] flex items-center justify-center mx-auto shadow-inner">
          <span className="material-symbols-outlined text-[36px]">check_circle</span>
        </div>

        <div>
          <span className="bg-emerald-50 text-[#006c4a] text-xs font-bold px-2.5 py-0.5 rounded-full uppercase tracking-wider">
            Appointment Confirmed
          </span>
          <h3 className="text-xl font-bold font-heading text-slate-900 mt-2">
            अपॉइंटमेंट निश्चित झाली!
          </h3>
          <p className="text-xs text-slate-500 mt-1">
            Confirmed with {appointment.doctorName}
          </p>
        </div>

        {/* Appointment Card Specs */}
        <div className="bg-slate-50 p-3.5 rounded-2xl border border-slate-100 text-left space-y-2 text-xs">
          <div className="flex justify-between border-b border-slate-200/60 pb-2">
            <span className="text-slate-400">Appointment ID:</span>
            <span className="font-mono font-bold text-slate-800">{appointment.id}</span>
          </div>

          <div className="flex justify-between">
            <span className="text-slate-500">Date &amp; Time:</span>
            <span className="font-bold text-slate-800">
              {appointment.date} • {appointment.timeSlot}
            </span>
          </div>

          <div className="flex justify-between">
            <span className="text-slate-500">Visit Type:</span>
            <span className="font-bold text-[#006c4a] capitalize">
              {appointment.visitType === 'home' ? 'Home Visit (घरी भेट)' : 'Clinic Visit (क्लिनिक)'}
            </span>
          </div>

          <div className="flex justify-between">
            <span className="text-slate-500">Pet:</span>
            <span className="font-bold text-slate-800 capitalize">
              {appointment.petType}
            </span>
          </div>

          <div className="flex justify-between border-t border-slate-200/60 pt-2 font-bold text-sm">
            <span className="text-slate-800">Consultation Fee:</span>
            <span className="text-[#ab3500]">₹{appointment.fee}</span>
          </div>
        </div>

        <p className="text-[11px] text-slate-400">
          A confirmation SMS has been sent to your registered mobile number with clinic directions in Sangli.
        </p>

        {/* Buttons */}
        <div className="flex flex-col gap-2 pt-1">
          <button
            onClick={() => {
              alert('Appointment reminder added to device calendar! (कॅलेंडरमध्ये जोडले)');
              onClose();
            }}
            className="w-full py-3 rounded-xl bg-[#006c4a] text-white font-bold text-xs shadow-md active:scale-98 transition-all flex items-center justify-center gap-1.5"
            type="button"
          >
            <span className="material-symbols-outlined text-[16px]">calendar_add_on</span>
            <span>Add to Calendar / कॅलेंडरमध्ये जोडा</span>
          </button>

          <button
            onClick={onClose}
            className="w-full py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs transition-colors"
            type="button"
          >
            Done / पूर्ण झाले
          </button>
        </div>
      </div>
    </div>
  );
};
