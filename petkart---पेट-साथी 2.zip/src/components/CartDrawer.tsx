import React, { useState } from 'react';
import { CartItem } from '../types';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  cart: CartItem[];
  onUpdateQuantity: (productId: string, delta: number) => void;
  onClearCart: () => void;
}

export const CartDrawer: React.FC<CartDrawerProps> = ({
  isOpen,
  onClose,
  cart,
  onUpdateQuantity,
  onClearCart,
}) => {
  const [promoCode, setPromoCode] = useState('');
  const [appliedPromo, setAppliedPromo] = useState<string | null>('FREESHIP');
  const [isPlacingOrder, setIsPlacingOrder] = useState(false);
  const [orderConfirmed, setOrderConfirmed] = useState(false);

  if (!isOpen) return null;

  const subtotal = cart.reduce((acc, item) => acc + item.product.price * item.quantity, 0);
  const deliveryFee = appliedPromo === 'FREESHIP' || subtotal > 499 ? 0 : 40;
  const total = subtotal + deliveryFee;

  const handleApplyPromo = () => {
    if (promoCode.trim().toUpperCase() === 'FREESHIP' || promoCode.trim().toUpperCase() === 'FIRSTVET') {
      setAppliedPromo(promoCode.trim().toUpperCase());
      setPromoCode('');
    } else {
      alert('Invalid Promo code. Try FREESHIP or FIRSTVET');
    }
  };

  const handleCheckout = () => {
    setIsPlacingOrder(true);
    setTimeout(() => {
      setIsPlacingOrder(false);
      setOrderConfirmed(true);
      setTimeout(() => {
        onClearCart();
      }, 400);
    }, 1200);
  };

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-black/60 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-white w-full max-w-md h-full flex flex-col shadow-2xl relative">
        {/* Top Header */}
        <div className="p-4 border-b border-slate-100 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="material-symbols-outlined text-[#ff6b35] text-[24px]">
              shopping_bag
            </span>
            <div>
              <h3 className="font-bold font-heading text-lg text-slate-900 leading-tight">
                Your Pet Cart ({cart.reduce((a, b) => a + b.quantity, 0)})
              </h3>
              <span className="text-xs text-slate-500">तुमची खरेदी कार्ट • Sangli</span>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-9 h-9 rounded-full bg-slate-100 text-slate-600 flex items-center justify-center hover:bg-slate-200 transition-colors"
            type="button"
          >
            <span className="material-symbols-outlined text-[20px]">close</span>
          </button>
        </div>

        {orderConfirmed ? (
          /* Order Confirmed View */
          <div className="flex-1 flex flex-col items-center justify-center p-6 text-center space-y-4">
            <div className="w-20 h-20 rounded-full bg-emerald-100 text-[#006c4a] flex items-center justify-center shadow-inner animate-bounce">
              <span className="material-symbols-outlined text-[44px]">task_alt</span>
            </div>
            <div>
              <h3 className="text-xl font-bold font-heading text-slate-900">
                Order Confirmed! 🚀
              </h3>
              <p className="text-sm font-medium text-[#006c4a] mt-1">
                ऑर्डर यशस्वीरित्या नोंदवली गेली!
              </p>
              <p className="text-xs text-slate-500 mt-2 max-w-xs mx-auto">
                Arriving in approx <strong>25–30 minutes</strong> at Vishrambag, Sangli via express pet-runner delivery.
              </p>
            </div>

            <div className="bg-slate-50 p-4 rounded-2xl border border-slate-100 w-full text-left space-y-1 text-xs text-slate-600">
              <div className="flex justify-between font-bold text-slate-800">
                <span>Order ID: #PK-SAN-{Math.floor(1000 + Math.random() * 9000)}</span>
                <span className="text-[#006c4a]">Paid: ₹{total}</span>
              </div>
              <p>Delivery Agent: <strong>Sagar Patil (+91 98810 54321)</strong></p>
              <p>Tracking: Dispatched from Sangli Central Depot</p>
            </div>

            <button
              onClick={() => {
                setOrderConfirmed(false);
                onClose();
              }}
              className="w-full py-3 rounded-xl bg-[#ff6b35] text-white font-bold text-sm shadow-md transition-all active:scale-98"
            >
              Continue Shopping / खरेदी सुरू ठेवा
            </button>
          </div>
        ) : cart.length === 0 ? (
          /* Empty Cart State */
          <div className="flex-1 flex flex-col items-center justify-center p-6 text-center space-y-3">
            <div className="w-16 h-16 rounded-full bg-slate-100 text-slate-400 flex items-center justify-center">
              <span className="material-symbols-outlined text-[32px]">remove_shopping_cart</span>
            </div>
            <p className="text-base font-bold text-slate-700">Your cart is empty</p>
            <p className="text-xs text-slate-400">कार्टमध्ये अद्याप कोणतीही वस्तू नाही</p>
            <button
              onClick={onClose}
              className="px-4 py-2 bg-[#ff6b35] text-white text-xs font-bold rounded-lg shadow-sm"
            >
              Explore Pet Food &amp; Toys
            </button>
          </div>
        ) : (
          /* Normal Cart List */
          <div className="flex-1 flex flex-col justify-between overflow-hidden">
            {/* 30-min Delivery Guarantee Banner */}
            <div className="bg-amber-500/10 border-b border-amber-200/50 px-4 py-2.5 flex items-center gap-2 text-xs text-amber-900">
              <span className="material-symbols-outlined text-amber-600 text-[18px]">bolt</span>
              <span>
                <strong>Instant 30-Min Delivery:</strong> Sangli City fast delivery!
              </span>
            </div>

            {/* Scrollable Items */}
            <div className="flex-1 overflow-y-auto p-4 space-y-3">
              {cart.map((item) => (
                <div
                  key={item.product.id}
                  className="flex items-center gap-3 p-2.5 bg-slate-50 rounded-xl border border-slate-100"
                >
                  <img
                    src={item.product.image}
                    alt={item.product.name}
                    className="w-14 h-14 object-cover rounded-lg bg-white shrink-0"
                  />
                  <div className="flex-1 min-w-0">
                    <h4 className="text-xs font-bold text-slate-800 truncate">
                      {item.product.name}
                    </h4>
                    <span className="text-[11px] text-slate-500 block">
                      {item.product.weight}
                    </span>
                    <span className="text-xs font-bold text-[#ab3500] mt-0.5 block">
                      ₹{item.product.price}
                    </span>
                  </div>

                  {/* Quantity Stepper */}
                  <div className="flex items-center gap-1.5 bg-white border border-slate-200 rounded-lg p-1">
                    <button
                      onClick={() => onUpdateQuantity(item.product.id, -1)}
                      className="w-6 h-6 rounded flex items-center justify-center text-slate-600 hover:bg-slate-100 active:scale-90"
                      type="button"
                    >
                      <span className="material-symbols-outlined text-[16px]">remove</span>
                    </button>
                    <span className="text-xs font-bold text-slate-800 min-w-[16px] text-center">
                      {item.quantity}
                    </span>
                    <button
                      onClick={() => onUpdateQuantity(item.product.id, 1)}
                      className="w-6 h-6 rounded flex items-center justify-center text-slate-600 hover:bg-slate-100 active:scale-90"
                      type="button"
                    >
                      <span className="material-symbols-outlined text-[16px]">add</span>
                    </button>
                  </div>
                </div>
              ))}

              {/* Promo Code Input */}
              <div className="pt-2">
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={promoCode}
                    onChange={(e) => setPromoCode(e.target.value)}
                    placeholder="Coupon code (e.g. FREESHIP)"
                    className="flex-1 h-10 px-3 bg-slate-50 border border-slate-200 rounded-xl text-xs outline-none focus:border-[#ff6b35]"
                  />
                  <button
                    onClick={handleApplyPromo}
                    className="px-3 h-10 bg-slate-800 hover:bg-slate-900 text-white rounded-xl text-xs font-bold transition-colors"
                  >
                    Apply
                  </button>
                </div>
                {appliedPromo && (
                  <div className="mt-1.5 flex items-center justify-between text-[11px] text-[#006c4a] bg-emerald-50 px-2.5 py-1 rounded-lg">
                    <span>Applied Coupon: <strong>{appliedPromo}</strong></span>
                    <button
                      onClick={() => setAppliedPromo(null)}
                      className="text-slate-400 hover:text-red-500"
                    >
                      Remove
                    </button>
                  </div>
                )}
              </div>

              {/* Delivery Locality Selection */}
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-100 text-xs space-y-1">
                <div className="flex items-center gap-1.5 text-slate-700 font-semibold">
                  <span className="material-symbols-outlined text-[16px] text-[#006c4a]">
                    pin_drop
                  </span>
                  <span>Delivery Address:</span>
                </div>
                <p className="text-slate-600 text-[11px]">
                  Flat 402, Samarth Residency, Vishrambag, Sangli (416415)
                </p>
              </div>
            </div>

            {/* Bill & Checkout Dock */}
            <div className="p-4 bg-white border-t border-slate-100 space-y-3">
              <div className="space-y-1 text-xs text-slate-600">
                <div className="flex justify-between">
                  <span>Subtotal</span>
                  <span>₹{subtotal}</span>
                </div>
                <div className="flex justify-between">
                  <span>Delivery (30-min express)</span>
                  <span>
                    {deliveryFee === 0 ? (
                      <span className="text-[#006c4a] font-bold">FREE</span>
                    ) : (
                      `₹${deliveryFee}`
                    )}
                  </span>
                </div>
                <div className="flex justify-between text-sm font-bold text-slate-900 pt-1 border-t border-slate-100">
                  <span>Total Payable</span>
                  <span className="text-[#ab3500]">₹{total}</span>
                </div>
              </div>

              <button
                disabled={isPlacingOrder}
                onClick={handleCheckout}
                className="w-full h-12 rounded-xl bg-[#006c4a] hover:bg-[#005137] active:scale-98 text-white font-bold text-sm shadow-md flex items-center justify-center gap-2 transition-all disabled:opacity-70"
                type="button"
              >
                {isPlacingOrder ? (
                  <>
                    <span className="material-symbols-outlined text-[20px] animate-spin">
                      progress_activity
                    </span>
                    <span>Placing 30-min Order...</span>
                  </>
                ) : (
                  <>
                    <span className="material-symbols-outlined text-[20px]">
                      shopping_bag
                    </span>
                    <span>Pay ₹{total} &amp; Deliver in 30 mins</span>
                  </>
                )}
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
