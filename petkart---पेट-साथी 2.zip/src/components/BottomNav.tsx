import React from 'react';
import { TabType } from '../types';

interface BottomNavProps {
  currentTab: TabType;
  onChangeTab: (tab: TabType) => void;
  cartCount?: number;
}

export const BottomNav: React.FC<BottomNavProps> = ({
  currentTab,
  onChangeTab,
  cartCount = 0,
}) => {
  const navItems: {
    key: TabType;
    labelEn: string;
    labelMr: string;
    icon: string;
    badge?: number;
  }[] = [
    { key: 'home', labelEn: 'Home', labelMr: 'मुख्य पान', icon: 'home' },
    { key: 'marketplace', labelEn: 'Pets', labelMr: 'खरेदी-विक्री', icon: 'pets' },
    {
      key: 'shop',
      labelEn: 'Shop',
      labelMr: 'दुकान',
      icon: 'shopping_bag',
      badge: cartCount > 0 ? cartCount : undefined,
    },
    { key: 'vetcare', labelEn: 'Vet Care', labelMr: 'डॉक्टर', icon: 'stethoscope' },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 bg-[#ffffff]/95 backdrop-blur-xl border-t border-slate-100 shadow-[0_-4px_24px_rgba(15,23,42,0.08)]">
      <div className="h-16 max-w-lg mx-auto grid grid-cols-4 items-center px-1">
        {navItems.map((item) => {
          const isActive = currentTab === item.key;
          return (
            <button
              key={item.key}
              onClick={() => onChangeTab(item.key)}
              className={`flex flex-col items-center justify-center h-full min-h-[48px] py-1 transition-all group ${
                isActive
                  ? 'text-[#ff6b35] font-semibold'
                  : 'text-[#594139] hover:text-[#131b2e]'
              }`}
              type="button"
            >
              <div
                className={`relative px-3.5 py-1 rounded-full flex items-center justify-center transition-all ${
                  isActive ? 'bg-[#ff6b35]/15' : 'group-hover:bg-slate-100'
                }`}
              >
                <span
                  className={`material-symbols-outlined text-[22px] transition-transform ${
                    isActive ? 'scale-110 text-[#ff6b35]' : 'text-slate-600'
                  }`}
                  style={{ fontVariationSettings: isActive ? "'FILL' 1" : "'FILL' 0" }}
                >
                  {item.icon === 'stethoscope' ? 'stethoscope' : item.icon}
                </span>

                {item.badge !== undefined && (
                  <span className="absolute -top-1 -right-1 min-w-[18px] h-4 px-1 rounded-full bg-[#ff6b35] text-white text-[10px] font-bold flex items-center justify-center shadow-sm">
                    {item.badge}
                  </span>
                )}
              </div>

              <span className="text-[11px] font-medium tracking-tight text-center leading-tight mt-0.5">
                {item.labelEn}{' '}
                <span className="text-[9px] opacity-75 font-normal block">
                  {item.labelMr}
                </span>
              </span>

              <span
                className={`w-1.5 h-1.5 rounded-full bg-[#ff6b35] mt-0.5 transition-opacity ${
                  isActive ? 'opacity-100' : 'opacity-0'
                }`}
              />
            </button>
          );
        })}
      </div>
    </nav>
  );
};
