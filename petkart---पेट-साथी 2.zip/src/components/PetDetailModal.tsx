import React, { useState } from 'react';
import { Pet } from '../types';

interface PetDetailModalProps {
  pet: Pet | null;
  onClose: () => void;
  isFavorite: boolean;
  onToggleFavorite: (petId: string) => void;
  onBookVetVisit?: (pet: Pet) => void;
}

export const PetDetailModal: React.FC<PetDetailModalProps> = ({
  pet,
  onClose,
  isFavorite,
  onToggleFavorite,
  onBookVetVisit,
}) => {
  const [activeImageIndex, setActiveImageIndex] = useState(0);
  const [contactSuccess, setContactSuccess] = useState<string | null>(null);

  if (!pet) return null;

  const handleCall = () => {
    setContactSuccess(`Calling ${pet.sellerName} at ${pet.sellerPhone}... (कॉल जोडला जात आहे)`);
    setTimeout(() => setContactSuccess(null), 3500);
  };

  const handleWhatsApp = () => {
    setContactSuccess(`Opening WhatsApp chat with ${pet.sellerName}... (व्हॉट्सॲप चॅट उघडत आहे)`);
    setTimeout(() => setContactSuccess(null), 3500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/60 backdrop-blur-sm p-0 sm:p-4 animate-in fade-in duration-200">
      <div className="bg-[#ffffff] w-full max-w-lg rounded-t-3xl sm:rounded-3xl max-h-[92vh] flex flex-col overflow-hidden shadow-2xl relative">
        {/* Top Floating Controls */}
        <div className="absolute top-3 left-3 right-3 z-20 flex items-center justify-between pointer-events-none">
          <button
            onClick={onClose}
            className="w-10 h-10 rounded-full bg-white/90 backdrop-blur-md text-slate-700 hover:text-slate-900 shadow-md flex items-center justify-center pointer-events-auto active:scale-90 transition-transform"
            type="button"
          >
            <span className="material-symbols-outlined text-[20px]">close</span>
          </button>

          <button
            onClick={() => onToggleFavorite(pet.id)}
            className="w-10 h-10 rounded-full bg-white/90 backdrop-blur-md shadow-md flex items-center justify-center pointer-events-auto active:scale-90 transition-transform"
            type="button"
          >
            <span
              className={`material-symbols-outlined text-[20px] ${
                isFavorite ? 'text-red-500' : 'text-slate-500'
              }`}
              style={{ fontVariationSettings: isFavorite ? "'FILL' 1" : "'FILL' 0" }}
            >
              favorite
            </span>
          </button>
        </div>

        {/* Scrollable Content */}
        <div className="overflow-y-auto flex-1 pb-24">
          {/* Main Photo Gallery */}
          <div className="relative w-full aspect-[4/3] bg-slate-100">
            <img
              src={pet.images[activeImageIndex] || pet.images[0]}
              alt={pet.name}
              className="w-full h-full object-cover"
            />

            {/* Badges Overlay */}
            <div className="absolute bottom-3 left-3 flex flex-wrap gap-1.5">
              {pet.isAdoption && (
                <span className="bg-[#006c4a] text-white px-2.5 py-1 rounded-full text-xs font-bold shadow-md flex items-center gap-1">
                  <span className="material-symbols-outlined text-[14px]">volunteer_activism</span>
                  Free Adoption / मोफत दत्तक
                </span>
              )}
              {pet.badges.map((b, idx) => (
                <span
                  key={idx}
                  className="bg-white/95 backdrop-blur-md text-[#131b2e] px-2.5 py-1 rounded-full text-xs font-semibold shadow-sm flex items-center gap-1"
                >
                  <span className="material-symbols-outlined text-[14px] text-[#006c4a]">verified</span>
                  {b}
                </span>
              ))}
            </div>

            {/* Image Thumbnails indicator */}
            {pet.images.length > 1 && (
              <div className="absolute bottom-3 right-3 flex items-center gap-1.5 bg-black/40 backdrop-blur-sm px-2 py-1 rounded-full">
                {pet.images.map((_, i) => (
                  <button
                    key={i}
                    onClick={() => setActiveImageIndex(i)}
                    className={`h-2 rounded-full transition-all ${
                      activeImageIndex === i ? 'w-5 bg-[#ff6b35]' : 'w-2 bg-white/70'
                    }`}
                  />
                ))}
              </div>
            )}
          </div>

          {/* Details Section */}
          <div className="p-4 space-y-4">
            {/* Title & Price Header */}
            <div className="flex items-start justify-between gap-3 border-b border-slate-100 pb-3">
              <div>
                <div className="flex items-center gap-2">
                  <h2 className="text-xl font-bold font-heading text-[#131b2e]">
                    {pet.name}
                  </h2>
                  <span className="text-sm font-medium text-slate-500">
                    ({pet.nameMr})
                  </span>
                </div>
                <div className="flex items-center gap-1 mt-1 text-xs text-slate-600">
                  <span className="material-symbols-outlined text-[15px] text-[#006c4a]">
                    location_on
                  </span>
                  <span>{pet.location}</span>
                  <span className="text-slate-400">•</span>
                  <span className="text-[#006c4a] font-semibold">Sangli Verified</span>
                </div>
              </div>

              <div className="text-right">
                {pet.isAdoption ? (
                  <div>
                    <span className="text-2xl font-black text-[#006c4a]">₹0</span>
                    <span className="block text-[10px] uppercase font-bold text-emerald-700">
                      Free Love
                    </span>
                  </div>
                ) : (
                  <div>
                    <span className="text-2xl font-black text-[#ab3500]">
                      ₹{pet.price.toLocaleString('en-IN')}
                    </span>
                    <span className="block text-[10px] text-slate-500">
                      Negotiable / वाटाघाटी शक्य
                    </span>
                  </div>
                )}
              </div>
            </div>

            {/* Quick Specs Grid */}
            <div className="grid grid-cols-3 gap-2 text-center">
              <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-100">
                <span className="text-[10px] uppercase font-semibold text-slate-400 block">Age / वय</span>
                <span className="text-sm font-bold text-slate-800">{pet.age}</span>
                <span className="text-[10px] text-slate-500 block">({pet.ageMr})</span>
              </div>
              <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-100">
                <span className="text-[10px] uppercase font-semibold text-slate-400 block">Gender / लिंग</span>
                <span className="text-sm font-bold text-slate-800">{pet.gender}</span>
                <span className="text-[10px] text-slate-500 block">({pet.genderMr})</span>
              </div>
              <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-100">
                <span className="text-[10px] uppercase font-semibold text-slate-400 block">Breed / जात</span>
                <span className="text-sm font-bold text-slate-800 truncate block">{pet.breed}</span>
                <span className="text-[10px] text-slate-500 truncate block">({pet.breedMr})</span>
              </div>
            </div>

            {/* Health & Verification Trust Card */}
            <div className="p-3.5 rounded-2xl bg-[#eaedff] border border-indigo-100 space-y-2">
              <div className="flex items-center gap-2">
                <span className="material-symbols-outlined text-[#006c4a] filled text-[20px]">
                  verified_user
                </span>
                <h4 className="text-sm font-bold text-slate-900">
                  Verified Health Guarantee / आरोग्य खात्री
                </h4>
              </div>

              <div className="grid grid-cols-2 gap-2 text-xs">
                <div className="flex items-center gap-1.5 text-slate-700">
                  <span className={`material-symbols-outlined text-[16px] ${pet.isVaccinated ? 'text-[#006c4a]' : 'text-slate-400'}`}>
                    {pet.isVaccinated ? 'check_circle' : 'cancel'}
                  </span>
                  <span>Vaccinated / लस पूर्ण</span>
                </div>
                <div className="flex items-center gap-1.5 text-slate-700">
                  <span className={`material-symbols-outlined text-[16px] ${pet.isDewormed ? 'text-[#006c4a]' : 'text-slate-400'}`}>
                    {pet.isDewormed ? 'check_circle' : 'cancel'}
                  </span>
                  <span>Dewormed / जंतनाशक</span>
                </div>
                <div className="flex items-center gap-1.5 text-slate-700">
                  <span className={`material-symbols-outlined text-[16px] ${pet.isKciRegistered ? 'text-[#006c4a]' : 'text-slate-400'}`}>
                    {pet.isKciRegistered ? 'check_circle' : 'cancel'}
                  </span>
                  <span>KCI Registered / केसीआय</span>
                </div>
                <div className="flex items-center gap-1.5 text-slate-700">
                  <span className="material-symbols-outlined text-[16px] text-[#006c4a]">
                    check_circle
                  </span>
                  <span>Vet Doctor Approved</span>
                </div>
              </div>
            </div>

            {/* Pet Story & Temperament */}
            <div className="space-y-1.5">
              <h4 className="text-sm font-bold text-slate-900">
                Temperament &amp; Habits / स्वभाव व इतर माहिती
              </h4>
              <p className="text-sm text-slate-600 leading-relaxed">
                {pet.description}
              </p>
              <p className="text-xs text-slate-500 italic bg-amber-50/70 p-2 rounded-lg border border-amber-100">
                मराठी: {pet.descriptionMr}
              </p>
            </div>

            {/* Seller Contact Info */}
            <div className="p-3 rounded-xl bg-slate-50 border border-slate-100 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-10 h-10 rounded-full bg-slate-200 flex items-center justify-center text-slate-600 font-bold">
                  {pet.sellerName.charAt(0)}
                </div>
                <div>
                  <span className="text-xs text-slate-400 block">Verified Sangli Parent / Breeder</span>
                  <span className="text-sm font-bold text-slate-800">{pet.sellerName}</span>
                </div>
              </div>
              <span className="text-xs bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded-full font-semibold">
                KYC Done
              </span>
            </div>

            {/* Micro Toast */}
            {contactSuccess && (
              <div className="p-2.5 rounded-xl bg-slate-900 text-white text-xs text-center animate-in slide-in-from-bottom duration-150">
                {contactSuccess}
              </div>
            )}
          </div>
        </div>

        {/* Fixed Bottom Action Dock */}
        <div className="absolute bottom-0 inset-x-0 bg-white/95 backdrop-blur-md border-t border-slate-100 p-3 flex items-center gap-2 z-30">
          <button
            onClick={handleWhatsApp}
            className="flex-1 h-12 rounded-xl bg-emerald-600 hover:bg-emerald-700 active:scale-98 text-white font-bold text-sm flex items-center justify-center gap-2 shadow-sm transition-all"
            type="button"
          >
            <span className="material-symbols-outlined text-[20px]">chat</span>
            <span>WhatsApp / संपर्क</span>
          </button>

          <button
            onClick={handleCall}
            className="flex-1 h-12 rounded-xl bg-[#ff6b35] hover:bg-[#ab3500] active:scale-98 text-white font-bold text-sm flex items-center justify-center gap-2 shadow-md shadow-[#ff6b35]/25 transition-all"
            type="button"
          >
            <span className="material-symbols-outlined text-[20px]">call</span>
            <span>{pet.isAdoption ? 'Adopt / दत्तक घ्या' : 'Call Seller / फोन'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
