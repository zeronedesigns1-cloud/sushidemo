import React from 'react';
import { TabType } from '../types';

interface HeaderProps {
  currentTab: TabType | string;
  cartCount: number;
  onOpenCart?: () => void;
  onOpenProfile: () => void;
  onOpenNotifications: () => void;
  hasUnreadNotifications?: boolean;
  isFramed: boolean;
  onToggleFrame: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentTab,
  onOpenProfile,
  onOpenNotifications,
  hasUnreadNotifications = true,
  isFramed,
  onToggleFrame,
}) => {
  const getTabTitle = () => {
    switch (currentTab) {
      case 'marketplace':
        return 'Marketplace';
      case 'shop':
        return 'Shop';
      case 'vetcare':
        return 'Vetcare';
      case 'listing-form':
        return 'Post Listing';
      default:
        return 'Home';
    }
  };

  return (
    <header className="sticky top-0 w-full z-40 bg-[#ffffff]/95 backdrop-blur-xl border-b border-slate-100 shadow-[0_1px_12px_rgba(15,23,42,0.05)]">
      <div className="h-16 px-4 flex items-center justify-between gap-2 max-w-lg mx-auto md:max-w-none md:px-6">
        {/* Brand identity */}
        <div className="flex items-center gap-2.5 min-w-0">
          <div className="h-10 w-10 rounded-xl bg-gradient-to-br from-[#ff6b35] to-[#ab3500] p-1.5 flex items-center justify-center shadow-sm shrink-0">
            <span className="material-symbols-outlined text-[24px] text-white filled">
              pets
            </span>
          </div>
          <div className="flex flex-col truncate">
            <div className="flex items-center gap-1.5 leading-none">
              <span className="font-heading font-extrabold text-[19px] text-[#ab3500] tracking-tight">
                PetKart
              </span>
              <span className="font-medium text-[11px] text-[#594139] hidden xs:inline">
                • पेट साथी
              </span>
            </div>
            <div className="flex items-center gap-1 mt-0.5">
              <span className="material-symbols-outlined text-[13px] text-[#006c4a] leading-none">
                location_on
              </span>
              <span className="text-[11px] text-[#006c4a] font-semibold truncate">
                Sangli, MH
              </span>
            </div>
          </div>
        </div>

        {/* Action icons & desktop helpers */}
        <div className="flex items-center gap-1.5 shrink-0">
          <div className="text-right pr-2 hidden sm:block">
            <span className="text-xs font-bold text-slate-700 bg-slate-100 px-2 py-1 rounded-full uppercase tracking-wider">
              {getTabTitle()}
            </span>
          </div>

          {/* Frame Viewport Mode Toggle (Allows simulating mobile view vs fullscreen) */}
          <button
            onClick={onToggleFrame}
            title={isFramed ? 'Switch to Full Width View' : 'Switch to Mobile Shell View'}
            className="w-9 h-9 hidden md:flex items-center justify-center rounded-full text-slate-500 hover:text-slate-800 hover:bg-slate-100 transition-colors"
            type="button"
          >
            <span className="material-symbols-outlined text-[20px]">
              {isFramed ? 'fullscreen' : 'smartphone'}
            </span>
          </button>

          {/* Notifications button */}
          <button
            aria-label="Notifications"
            onClick={onOpenNotifications}
            className="relative w-10 h-10 flex items-center justify-center rounded-full text-[#594139] hover:text-[#131b2e] hover:bg-slate-100 transition-colors"
            type="button"
          >
            <span className="material-symbols-outlined text-[22px]">
              notifications
            </span>
            {hasUnreadNotifications && (
              <span className="absolute top-2 right-2 w-2 h-2 rounded-full bg-[#ff6b35] ring-2 ring-white" />
            )}
          </button>

          {/* Profile avatar */}
          <button
            onClick={onOpenProfile}
            aria-label="User Profile"
            className="w-10 h-10 flex items-center justify-center rounded-full ring-2 ring-[#ff6b35]/20 hover:ring-[#ff6b35] transition-all overflow-hidden"
            type="button"
          >
            <img
              alt="Sushant Pende Profile"
              className="w-8 h-8 rounded-full object-cover"
              src="https://lh3.googleusercontent.com/aida-public/AB6AXuAiQQ6fsbQpgjyg7nBpyO2NzUxX-1hrzB80NRsBQV-YmjpwndS7wu4x3PeDO_dFd4WBOI2xr-gr0F431SA9bMfnsf8QOjUfnMaYit4TCoyjkqU2upkOUUQnwKSdefDNO6VLHeZorSJn8WHENG0BlT0UxjX0UVC8nZu8nwanY2nlyV5ZNm4ruzzbybK7FPfrzIE3kkkHlG7IF8UX3rKsd90hiTcv9TW1ae80AdD-3QYLEKklmVdKD5wo"
            />
          </button>
        </div>
      </div>
    </header>
  );
};
