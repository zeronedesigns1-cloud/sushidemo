import React, { useState } from 'react';
import { Pet } from '../types';

interface MarketplaceScreenProps {
  pets: Pet[];
  onSelectPet: (pet: Pet) => void;
  favorites: string[];
  onToggleFavorite: (petId: string) => void;
  onOpenListingForm: () => void;
}

export const MarketplaceScreen: React.FC<MarketplaceScreenProps> = ({
  pets,
  onSelectPet,
  favorites,
  onToggleFavorite,
  onOpenListingForm,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedLocality, setSelectedLocality] = useState<string>('all');
  const [adoptionOnly, setAdoptionOnly] = useState<boolean>(false);

  const categoryOptions = [
    { key: 'all', labelEn: 'All', labelMr: 'सर्व', icon: 'pets' },
    { key: 'dogs', labelEn: 'Dogs', labelMr: 'कुत्रे', icon: 'sound_detection_dog_barking' },
    { key: 'cats', labelEn: 'Cats', labelMr: 'मांजरी', icon: 'cruelty_free' },
    { key: 'puppies', labelEn: 'Puppies', labelMr: 'पिल्ले', icon: 'pets' },
    { key: 'kittens', labelEn: 'Kittens', labelMr: 'मांजराची पिल्ले', icon: 'cruelty_free' },
    { key: 'birds', labelEn: 'Birds', labelMr: 'पक्षी', icon: 'flutter' },
  ];

  // Filtering
  const filteredPets = pets.filter((pet) => {
    // category filter
    if (selectedCategory !== 'all') {
      if (selectedCategory === 'puppies') {
        if (pet.category !== 'puppies' && !pet.name.toLowerCase().includes('pup')) return false;
      } else if (selectedCategory === 'kittens') {
        if (pet.category !== 'kittens' && !pet.name.toLowerCase().includes('kitten')) return false;
      } else if (selectedCategory === 'dogs') {
        if (pet.category !== 'dogs' && pet.category !== 'puppies') return false;
      } else if (selectedCategory === 'cats') {
        if (pet.category !== 'cats' && pet.category !== 'kittens') return false;
      } else if (selectedCategory === 'birds') {
        if (pet.category !== 'birds') return false;
      }
    }

    // adoption filter
    if (adoptionOnly && !pet.isAdoption) {
      return false;
    }

    // search query filter
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchName = pet.name.toLowerCase().includes(q) || pet.nameMr.includes(q);
      const matchBreed = pet.breed.toLowerCase().includes(q) || pet.breedMr.includes(q);
      const matchLocation = pet.location.toLowerCase().includes(q);
      if (!matchName && !matchBreed && !matchLocation) return false;
    }

    return true;
  });

  return (
    <div className="flex flex-col w-full pb-28 max-w-lg mx-auto">
      {/* Top Greeting & Search Meta Banner */}
      <section className="px-4 pt-3 pb-2">
        <div className="flex flex-col gap-1">
          <div className="flex items-center justify-between">
            <h1 className="text-lg font-bold font-heading text-slate-900 tracking-tight">
              Find Your Pet Companion
            </h1>
            <span className="inline-flex items-center gap-1 bg-[#82f5c1] text-[#00714e] px-2 py-0.5 rounded-full text-xs font-semibold">
              <span className="w-1.5 h-1.5 rounded-full bg-[#006c4a] animate-pulse" />
              Verified Vets
            </span>
          </div>
          <p className="text-xs text-slate-500 font-medium">
            तुमचा नवीन सोबती शोधा • Sangli verified breeders &amp; shelters
          </p>
        </div>

        {/* Interactive Search & Filter Quick Bar */}
        <div className="mt-3 flex items-center gap-2">
          <div className="flex-1 flex items-center bg-slate-100/90 rounded-2xl px-3 py-2 shadow-xs border border-slate-200/60 focus-within:border-[#ff6b35] transition-colors">
            <span className="material-symbols-outlined text-slate-400 text-[20px] mr-2">search</span>
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search breed, age, area... / शोधा"
              className="bg-transparent border-0 outline-none w-full text-xs text-slate-800 placeholder:text-slate-400"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="text-slate-400 hover:text-slate-600 p-0.5"
                type="button"
              >
                <span className="material-symbols-outlined text-[16px]">close</span>
              </button>
            )}
            <button
              onClick={() => {
                alert('Voice search activated: Speak your desired breed (उदा. गोल्डन रिट्रीव्हर)');
              }}
              aria-label="Voice Search"
              className="text-[#ff6b35] p-1 rounded-full hover:bg-white transition-colors"
              type="button"
            >
              <span className="material-symbols-outlined text-[18px]">mic</span>
            </button>
          </div>

          <button
            onClick={() => setAdoptionOnly(!adoptionOnly)}
            title="Filter Adoptions Only"
            aria-label="Filter Options"
            className={`p-2.5 rounded-2xl shadow-xs flex items-center justify-center transition-all ${
              adoptionOnly
                ? 'bg-[#006c4a] text-white shadow-sm'
                : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
            type="button"
          >
            <span className="material-symbols-outlined text-[20px]">
              {adoptionOnly ? 'volunteer_activism' : 'tune'}
            </span>
          </button>
        </div>
      </section>

      {/* Horizontal Choice Chips (Scrollable filter row) */}
      <section className="py-2">
        <div className="flex items-center gap-2 overflow-x-auto px-4 no-scrollbar">
          {categoryOptions.map((cat) => {
            const isActive = selectedCategory === cat.key;
            return (
              <button
                key={cat.key}
                onClick={() => setSelectedCategory(cat.key)}
                className={`shrink-0 font-heading text-xs px-3.5 py-1.5 rounded-full transition-all active:scale-95 flex items-center gap-1.5 ${
                  isActive
                    ? 'bg-[#ff6b35] text-white font-bold shadow-sm shadow-[#ff6b35]/30'
                    : 'bg-white text-slate-600 hover:text-slate-900 border border-slate-200/60 shadow-xs'
                }`}
                type="button"
              >
                <span className="material-symbols-outlined text-[16px]">{cat.icon}</span>
                <span>
                  {cat.labelEn}{' '}
                  <span className={`text-[10px] ${isActive ? 'opacity-90' : 'opacity-75'}`}>
                    ({cat.labelMr})
                  </span>
                </span>
              </button>
            );
          })}
        </div>
      </section>

      {/* Marketplace Stats & Health Safety Banner */}
      <section className="px-4 my-2">
        <div className="bg-gradient-to-r from-[#ffdbd0]/80 via-white to-slate-50 border border-[#ff6b35]/20 rounded-2xl p-3 flex items-center justify-between shadow-xs">
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="w-9 h-9 rounded-xl bg-white flex items-center justify-center text-[#ff6b35] shadow-xs shrink-0 border border-[#ffdbd0]">
              <span className="material-symbols-outlined text-[20px]">health_and_safety</span>
            </div>
            <div className="flex flex-col truncate">
              <span className="text-xs text-[#832600] font-bold leading-tight">
                100% Health Checked
              </span>
              <span className="text-[11px] text-slate-500 leading-tight truncate">
                लसीकरण व वैद्यकीय तपासणी केलेले पाळीव प्राणी
              </span>
            </div>
          </div>
          <span className="material-symbols-outlined text-[#006c4a] text-[18px]">verified</span>
        </div>
      </section>

      {/* Pets 2-Column Grid */}
      <section className="px-4 pt-2">
        <div className="flex items-center justify-between mb-2">
          <span className="text-xs font-bold text-slate-700">
            {filteredPets.length} Pets Available in Sangli
          </span>
          {adoptionOnly && (
            <span className="text-xs text-[#006c4a] font-bold bg-emerald-50 px-2 py-0.5 rounded-full">
              Showing Free Adoptions
            </span>
          )}
        </div>

        {filteredPets.length === 0 ? (
          <div className="bg-white p-8 rounded-2xl border border-slate-100 text-center space-y-2 mt-4">
            <span className="material-symbols-outlined text-[36px] text-slate-300">pets</span>
            <p className="text-sm font-bold text-slate-700">No pets found matching criteria</p>
            <p className="text-xs text-slate-400">वेगळा शब्द किंवा फिल्टर निवडून पहा</p>
            <button
              onClick={() => {
                setSelectedCategory('all');
                setSearchQuery('');
                setAdoptionOnly(false);
              }}
              className="mt-2 text-xs font-bold text-[#ff6b35] hover:underline"
            >
              Reset Filters
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-2 gap-3">
            {filteredPets.map((pet) => {
              const isFav = favorites.includes(pet.id);
              return (
                <article
                  key={pet.id}
                  onClick={() => onSelectPet(pet)}
                  className="bg-white rounded-2xl p-2.5 shadow-xs border border-slate-100 hover:shadow-md transition-shadow flex flex-col justify-between group cursor-pointer"
                >
                  {/* Photo with badges */}
                  <div className="relative w-full aspect-[4/3] rounded-xl overflow-hidden bg-slate-100">
                    <img
                      src={pet.images[0]}
                      alt={pet.name}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    />

                    {/* Favorite Button */}
                    <button
                      aria-label="Add to favorites"
                      onClick={(e) => {
                        e.stopPropagation();
                        onToggleFavorite(pet.id);
                      }}
                      className="absolute top-2 right-2 w-7 h-7 rounded-full bg-white/85 backdrop-blur-md flex items-center justify-center text-slate-500 hover:text-red-500 transition-colors shadow-xs"
                      type="button"
                    >
                      <span
                        className={`material-symbols-outlined text-[16px] ${
                          isFav ? 'text-red-500' : ''
                        }`}
                        style={{ fontVariationSettings: isFav ? "'FILL' 1" : "'FILL' 0" }}
                      >
                        favorite
                      </span>
                    </button>

                    {/* Free Adoption badge */}
                    {pet.isAdoption && (
                      <span className="absolute top-2 left-2 bg-[#006c4a] text-white text-[9px] px-2 py-0.5 rounded-full flex items-center gap-0.5 shadow-xs font-bold">
                        <span className="material-symbols-outlined text-[11px]">volunteer_activism</span>
                        Adopt
                      </span>
                    )}

                    {/* Verification label */}
                    <span className="absolute bottom-1.5 left-1.5 bg-white/90 backdrop-blur-sm text-slate-800 text-[10px] px-2 py-0.5 rounded-full flex items-center gap-1 shadow-xs font-medium">
                      <span className="material-symbols-outlined text-[12px] text-[#006c4a]">verified</span>
                      {pet.badges[0] || 'Verified'}
                    </span>
                  </div>

                  {/* Body Info */}
                  <div className="mt-2 flex flex-col gap-1">
                    <div>
                      <h2 className="text-xs font-bold font-heading text-slate-800 leading-tight truncate">
                        {pet.name}
                      </h2>
                      <span className="text-[11px] text-slate-400 truncate block">
                        {pet.nameMr}
                      </span>
                    </div>

                    <div className="flex items-center gap-1 text-slate-500 text-[11px]">
                      <span className="material-symbols-outlined text-[13px] text-[#ff6b35]">
                        event_note
                      </span>
                      <span className="truncate">
                        Age: {pet.age} / {pet.ageMr}
                      </span>
                    </div>

                    <div className="flex items-center gap-1 text-slate-500 text-[11px]">
                      <span className="material-symbols-outlined text-[13px] text-[#006c4a]">
                        pin_drop
                      </span>
                      <span className="truncate text-slate-500">
                        {pet.location.split(',')[0]}
                      </span>
                    </div>

                    {/* Price and View Button */}
                    <div className="mt-2 pt-2 flex items-center justify-between border-t border-slate-100 bg-slate-50/70 -mx-2.5 -mb-2.5 p-2.5 rounded-b-2xl">
                      {pet.isAdoption ? (
                        <div>
                          <span className="text-xs font-black text-[#006c4a]">₹0</span>
                          <span className="text-[9px] text-emerald-700 font-bold block">Free Love</span>
                        </div>
                      ) : (
                        <span className="text-xs font-black text-[#ab3500]">
                          ₹{pet.price.toLocaleString('en-IN')}
                        </span>
                      )}

                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onSelectPet(pet);
                        }}
                        className={`text-xs font-bold px-3 py-1.5 rounded-xl shadow-xs transition-colors flex items-center gap-0.5 active:scale-95 ${
                          pet.isAdoption
                            ? 'bg-[#006c4a] hover:bg-[#005137] text-white'
                            : 'bg-[#ff6b35] hover:bg-[#ab3500] text-white'
                        }`}
                        type="button"
                      >
                        <span>{pet.isAdoption ? 'Adopt' : 'View'}</span>
                        <span className="text-[10px] opacity-80">
                          {pet.isAdoption ? '/ घ्या' : '/ पाहा'}
                        </span>
                      </button>
                    </div>
                  </div>
                </article>
              );
            })}
          </div>
        )}
      </section>

      {/* Sticky Floating Action Button (Sell / Adopt Pet) */}
      <div className="fixed bottom-20 right-4 z-30">
        <button
          onClick={onOpenListingForm}
          className="inline-flex items-center gap-2 bg-gradient-to-r from-[#ff6b35] to-[#ab3500] text-white pl-4 pr-5 py-3 rounded-full shadow-lg shadow-[#ff6b35]/40 hover:scale-102 active:scale-95 transition-all group"
          type="button"
        >
          <div className="w-8 h-8 rounded-full bg-white/20 flex items-center justify-center shrink-0">
            <span className="material-symbols-outlined text-[20px] text-white group-hover:rotate-90 transition-transform duration-300">
              add_a_photo
            </span>
          </div>
          <div className="flex flex-col text-left">
            <span className="text-xs font-bold font-heading leading-tight drop-shadow-sm">
              Sell / Adopt Pet
            </span>
            <span className="text-[10px] text-[#ffdbd0] leading-tight font-medium">
              प्राणी विका किंवा दत्तक द्या
            </span>
          </div>
        </button>
      </div>
    </div>
  );
};
