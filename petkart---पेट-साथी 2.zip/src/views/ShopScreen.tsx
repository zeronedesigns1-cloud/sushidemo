import React, { useState } from 'react';
import { Product } from '../types';

interface ShopScreenProps {
  products: Product[];
  onAddToCart: (product: Product) => void;
  cartCount: number;
  onOpenCart: () => void;
}

export const ShopScreen: React.FC<ShopScreenProps> = ({
  products,
  onAddToCart,
  cartCount,
  onOpenCart,
}) => {
  const [activeCategory, setActiveCategory] = useState<'all' | 'food' | 'toys' | 'hygiene' | 'meds'>('food');
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [justAddedId, setJustAddedId] = useState<string | null>(null);

  const categories: { key: 'all' | 'food' | 'toys' | 'hygiene' | 'meds'; labelEn: string; labelMr: string; icon: string }[] = [
    { key: 'food', labelEn: 'Food', labelMr: 'खाद्य', icon: '🦴' },
    { key: 'toys', labelEn: 'Toys', labelMr: 'खेळणी', icon: '🎾' },
    { key: 'hygiene', labelEn: 'Hygiene', labelMr: 'स्वच्छता', icon: '🧼' },
    { key: 'meds', labelEn: 'Meds', labelMr: 'औषधे', icon: '💊' },
  ];

  const filteredProducts = activeCategory === 'all'
    ? products
    : products.filter((p) => p.category === activeCategory);

  const handleAdd = (product: Product) => {
    onAddToCart(product);
    setJustAddedId(product.id);
    setToastMessage(`${product.name} added! / कार्टमध्ये जोडले!`);

    setTimeout(() => {
      setJustAddedId(null);
    }, 1200);

    setTimeout(() => {
      setToastMessage(null);
    }, 2200);
  };

  return (
    <div className="flex flex-col w-full pb-28 max-w-lg mx-auto">
      {/* Express 30-min Delivery Banner */}
      <div className="px-4 pt-3 pb-1">
        <div className="bg-gradient-to-r from-[#d68900] via-[#ff6b35] to-[#ab3500] text-white rounded-2xl p-3 shadow-xs flex items-center gap-3 relative overflow-hidden">
          <div className="w-9 h-9 rounded-full bg-white/20 flex items-center justify-center shrink-0">
            <span className="material-symbols-outlined text-[20px] text-[#ffddb8] animate-pulse">
              bolt
            </span>
          </div>
          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-1.5 flex-wrap leading-tight">
              <span className="text-xs font-bold font-heading tracking-tight text-white">
                Instant 30-min delivery
              </span>
              <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-white/25 text-white font-semibold">
                Sangli
              </span>
            </div>
            <p className="text-[11px] text-[#ffdbd0] truncate mt-0.5">
              सांगली शहरात ३० मिनिटांत जलद डिलिव्हरी!
            </p>
          </div>
          <div className="shrink-0 flex items-center pr-1 text-white/80">
            <span className="material-symbols-outlined text-[20px]">local_shipping</span>
          </div>
        </div>
      </div>

      {/* Header Row with Bilingual Title and Dynamic Cart Trigger */}
      <div className="px-4 pt-3 pb-1 flex items-center justify-between gap-3">
        <div className="min-w-0 flex-1">
          <h1 className="text-lg font-bold font-heading text-slate-900 tracking-tight leading-snug">
            Pet Food &amp; Accessories
          </h1>
          <p className="text-xs text-slate-500 font-medium">खाद्य व पाळीव प्राण्यांच्या वस्तू</p>
        </div>

        {/* Floating Cart Badge Button */}
        <button
          onClick={onOpenCart}
          aria-label="Shopping Cart"
          className="relative w-11 h-11 rounded-2xl bg-[#eaedff] flex items-center justify-center text-slate-800 hover:bg-[#dae2fd] transition-all active:scale-95 shadow-xs"
          type="button"
        >
          <span className="material-symbols-outlined text-[22px] text-[#ff6b35]">shopping_bag</span>
          {cartCount > 0 && (
            <span className="absolute -top-1 -right-1 min-w-[20px] h-5 px-1 rounded-full bg-[#ff6b35] text-white text-[10px] font-bold flex items-center justify-center shadow-md animate-in zoom-in-50 duration-150">
              {cartCount}
            </span>
          )}
        </button>
      </div>

      {/* Category Tabs with Horizontal Scrolling */}
      <div className="pt-2 pb-2">
        <div className="flex items-center gap-2 overflow-x-auto px-4 no-scrollbar py-1">
          {categories.map((cat) => {
            const isActive = activeCategory === cat.key;
            return (
              <button
                key={cat.key}
                onClick={() => setActiveCategory(cat.key)}
                className={`shrink-0 flex items-center gap-1.5 px-3.5 py-1.5 rounded-full text-xs transition-all ${
                  isActive
                    ? 'bg-[#ff6b35] text-white font-bold shadow-sm'
                    : 'bg-white text-slate-600 hover:text-slate-900 border border-slate-200/60 shadow-xs'
                }`}
                type="button"
              >
                <span className="text-sm leading-none">{cat.icon}</span>
                <span>
                  {cat.labelEn}{' '}
                  <span className={`text-[10px] ${isActive ? 'opacity-90' : 'opacity-70'}`}>
                    ({cat.labelMr})
                  </span>
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Product Count & Quick Filter Utility */}
      <div className="px-4 pb-2 flex items-center justify-between text-slate-500 text-xs">
        <span className="font-semibold tracking-wide uppercase text-[11px]">
          {filteredProducts.length} Essentials Available
        </span>
        <div className="flex items-center gap-1 text-[#006c4a] font-semibold">
          <span className="material-symbols-outlined text-[16px]">verified</span>
          <span>100% Genuine</span>
        </div>
      </div>

      {/* Vertical ListView of Product Cards */}
      <div className="px-4 flex flex-col gap-3">
        {filteredProducts.map((product) => {
          const isAdded = justAddedId === product.id;
          return (
            <div
              key={product.id}
              className="w-full bg-white rounded-2xl p-3 shadow-xs border border-slate-100 hover:shadow-md transition-all flex gap-3 relative"
            >
              {/* Product Image */}
              <div className="w-[90px] h-[105px] rounded-xl bg-slate-50 overflow-hidden shrink-0 relative border border-slate-100">
                <img
                  src={product.image}
                  alt={product.name}
                  className="w-full h-full object-cover object-center"
                />
                {product.discountBadge && (
                  <span
                    className={`absolute top-1 left-1 font-bold text-[9px] px-1.5 py-0.5 rounded leading-tight shadow-xs ${
                      product.discountBadge.includes('OFF')
                        ? 'bg-[#ba1a1a] text-white'
                        : product.discountBadge === 'Organic'
                        ? 'bg-[#006c4a] text-white'
                        : product.discountBadge === 'Herbal'
                        ? 'bg-[#82f5c1] text-[#00714e]'
                        : 'bg-[#d68900] text-white'
                    }`}
                  >
                    {product.discountBadge}
                  </span>
                )}
              </div>

              {/* Column Details */}
              <div className="flex-1 flex flex-col justify-between min-w-0 py-0.5">
                <div>
                  <h2 className="text-xs font-bold font-heading text-slate-800 leading-tight truncate">
                    {product.name}
                  </h2>
                  <p className="text-[11px] text-slate-500 truncate mt-0.5">
                    {product.weight} / {product.weightMr}
                  </p>

                  {/* Rating Row */}
                  <div className="flex items-center gap-1 mt-1">
                    <span
                      className="material-symbols-outlined text-[15px] text-amber-500"
                      style={{ fontVariationSettings: "'FILL' 1" }}
                    >
                      star
                    </span>
                    <span className="text-xs font-bold text-slate-800">{product.rating}</span>
                    <span className="text-[10px] text-slate-400">
                      ({product.reviewsCount} reviews)
                    </span>
                  </div>
                </div>

                {/* Price & Action Row */}
                <div className="flex items-center justify-between gap-2 mt-2">
                  <div className="flex items-baseline gap-1.5">
                    <span className="text-sm font-bold text-[#006c4a]">
                      ₹{product.price}
                    </span>
                    {product.originalPrice && (
                      <span className="text-xs text-slate-400 line-through">
                        ₹{product.originalPrice}
                      </span>
                    )}
                  </div>

                  <button
                    onClick={() => handleAdd(product)}
                    className={`shrink-0 flex items-center gap-1 px-3 py-1.5 rounded-full text-xs font-semibold shadow-xs active:scale-95 transition-all ${
                      isAdded
                        ? 'bg-[#006c4a] text-white'
                        : 'bg-[#ff6b35] hover:bg-[#ab3500] text-white'
                    }`}
                    type="button"
                  >
                    <span className="material-symbols-outlined text-[15px]">
                      {isAdded ? 'done' : 'add_shopping_cart'}
                    </span>
                    <span>
                      {isAdded ? (
                        'Added!'
                      ) : (
                        <>
                          Add <span className="text-[10px] font-normal opacity-90 block xs:inline">/ जोडा</span>
                        </>
                      )}
                    </span>
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Micro-Toast for Instant Feedback */}
      {toastMessage && (
        <div className="fixed bottom-20 left-1/2 -translate-x-1/2 bg-[#131b2e] text-white px-4 py-2 rounded-full shadow-xl text-xs flex items-center gap-2 z-50 animate-in fade-in slide-in-from-bottom duration-200">
          <span className="material-symbols-outlined text-[16px] text-[#82f5c1]">check_circle</span>
          <span>{toastMessage}</span>
        </div>
      )}
    </div>
  );
};
