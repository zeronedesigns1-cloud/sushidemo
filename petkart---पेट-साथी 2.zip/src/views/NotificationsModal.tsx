import React from 'react';

interface NotificationsModalProps {
  isOpen: boolean;
  onClose: () => void;
  onNavigateToVet: () => void;
  onNavigateToShop: () => void;
}

export const NotificationsModal: React.FC<NotificationsModalProps> = ({
  isOpen,
  onClose,
  onNavigateToVet,
  onNavigateToShop,
}) => {
  if (!isOpen) return null;

  const notifications = [
    {
      id: '1',
      title: 'Appointment Confirmed! 🩺',
      titleMr: 'अपॉइंटमेंट नोंदणी झाली',
      message: 'Your consultation with Dr. Amit Patil is confirmed for tomorrow 02:30 PM.',
      time: '10 mins ago',
      icon: 'event_available',
      type: 'vet',
      unread: true,
    },
    {
      id: '2',
      title: 'Flash Sale: 11% Off Whiskas Cat Food 🐱',
      titleMr: 'कॅट फूडवर ११% सूट',
      message: 'Instant 30-min express delivery active in Vishrambag & Ganpati Peth.',
      time: '1 hour ago',
      icon: 'local_offer',
      type: 'shop',
      unread: true,
    },
    {
      id: '3',
      title: 'New Puppy for Free Adoption 🐾',
      titleMr: 'नवीन पिल्लू मोफत दत्तक',
      message: 'Indie pup Milo rescued in Kupwad is ready for a warm loving home in Sangli.',
      time: '3 hours ago',
      icon: 'volunteer_activism',
      type: 'pet',
      unread: false,
    },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 animate-in fade-in duration-200">
      <div className="bg-white w-full max-w-sm rounded-3xl max-h-[85vh] flex flex-col overflow-hidden shadow-2xl">
        {/* Header */}
        <div className="p-4 border-b border-slate-100 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="material-symbols-outlined text-[#ff6b35]">notifications</span>
            <h3 className="font-bold font-heading text-slate-900 text-base">
              Notifications / सूचना
            </h3>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-100 text-slate-600 flex items-center justify-center hover:bg-slate-200"
            type="button"
          >
            <span className="material-symbols-outlined text-[18px]">close</span>
          </button>
        </div>

        {/* List */}
        <div className="overflow-y-auto p-4 space-y-2.5">
          {notifications.map((n) => (
            <div
              key={n.id}
              onClick={() => {
                if (n.type === 'vet') onNavigateToVet();
                else if (n.type === 'shop') onNavigateToShop();
                onClose();
              }}
              className={`p-3 rounded-2xl border transition-all cursor-pointer flex gap-3 items-start ${
                n.unread
                  ? 'bg-[#eaedff]/60 border-[#ff6b35]/20 hover:border-[#ff6b35]'
                  : 'bg-slate-50 border-slate-100 hover:bg-slate-100'
              }`}
            >
              <div
                className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${
                  n.type === 'vet'
                    ? 'bg-[#82f5c1] text-[#006c4a]'
                    : n.type === 'shop'
                    ? 'bg-[#ffdbd0] text-[#ab3500]'
                    : 'bg-amber-100 text-amber-800'
                }`}
              >
                <span className="material-symbols-outlined text-[20px]">{n.icon}</span>
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between">
                  <h4 className="text-xs font-bold text-slate-900 truncate">{n.title}</h4>
                  {n.unread && (
                    <span className="w-2 h-2 rounded-full bg-[#ff6b35] shrink-0" />
                  )}
                </div>
                <p className="text-[11px] text-slate-600 mt-0.5 leading-snug">{n.message}</p>
                <span className="text-[10px] text-slate-400 mt-1 block">{n.time}</span>
              </div>
            </div>
          ))}
        </div>

        {/* Footer */}
        <div className="p-3 bg-slate-50 border-t border-slate-100 text-center">
          <button
            onClick={onClose}
            className="text-xs font-bold text-[#ff6b35] hover:underline"
          >
            Mark all as read / सर्व वाचलेले चिन्हांकित करा
          </button>
        </div>
      </div>
    </div>
  );
};
