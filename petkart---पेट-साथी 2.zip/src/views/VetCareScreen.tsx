import React, { useState } from 'react';
import { Appointment, Doctor } from '../types';

interface VetCareScreenProps {
  doctors: Doctor[];
  onAppointmentBooked: (appointment: Appointment) => void;
}

export const VetCareScreen: React.FC<VetCareScreenProps> = ({
  doctors,
  onAppointmentBooked,
}) => {
  const [selectedDoctorId, setSelectedDoctorId] = useState<string>(doctors[0]?.id || 'doc-1');
  const [selectedPet, setSelectedPet] = useState<'dog' | 'cat' | 'other'>('dog');
  const [selectedDate, setSelectedDate] = useState<{ day: string; num: string; labelEn: string; labelMr: string }>({
    day: 'Tomorrow',
    num: '25',
    labelEn: 'Tomorrow',
    labelMr: 'उद्या',
  });
  const [selectedTime, setSelectedTime] = useState<string>('02:30 PM');
  const [visitType, setVisitType] = useState<'clinic' | 'home'>('clinic');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const selectedDoctor = doctors.find((d) => d.id === selectedDoctorId) || doctors[0];
  const consultationFee = visitType === 'home' ? selectedDoctor.homeVisitFee : selectedDoctor.clinicFee;

  const dateOptions = [
    { day: 'Thu', num: '24', labelEn: 'Today', labelMr: 'आज' },
    { day: 'Tomorrow', num: '25', labelEn: 'Tomorrow', labelMr: 'उद्या' },
    { day: 'Sat', num: '26', labelEn: 'Sat', labelMr: 'शनि' },
    { day: 'Sun', num: '27', labelEn: 'Sun', labelMr: 'रवि' },
  ];

  const timeSlots = [
    { time: '10:00 AM', icon: 'wb_sunny' },
    { time: '02:30 PM', icon: 'schedule' },
    { time: '06:00 PM', icon: 'wb_twilight' },
    { time: '07:30 PM', icon: 'dark_mode' },
  ];

  const handleBookingSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    const newAppointment: Appointment = {
      id: `APT-${Math.floor(10000 + Math.random() * 90000)}`,
      doctorId: selectedDoctor.id,
      doctorName: selectedDoctor.name,
      petType: selectedPet,
      date: `${selectedDate.num}/10/2024 (${selectedDate.labelMr})`,
      timeSlot: selectedTime,
      visitType: visitType,
      fee: consultationFee,
      status: 'confirmed',
      timestamp: new Date().toLocaleTimeString(),
    };

    setTimeout(() => {
      setIsSubmitting(false);
      onAppointmentBooked(newAppointment);
    }, 900);
  };

  return (
    <div className="flex flex-col w-full pb-28 max-w-lg mx-auto">
      {/* Top Progress & Safety Banner */}
      <div className="px-4 pt-3 pb-2 flex items-center justify-between">
        <div className="flex items-center gap-1.5">
          <span className="w-6 h-6 rounded-full bg-[#ff6b35] text-white text-xs flex items-center justify-center font-bold">
            1
          </span>
          <span className="text-xs font-bold text-slate-800">Doctor &amp; Slot</span>
          <span className="material-symbols-outlined text-[16px] text-slate-400">chevron_right</span>
          <span className="text-xs text-slate-400">Payment</span>
        </div>
        <div className="flex items-center gap-1 bg-[#82f5c1]/25 px-2.5 py-0.5 rounded-full border border-[#82f5c1]/40">
          <span className="material-symbols-outlined text-[14px] text-[#006c4a]">verified</span>
          <span className="text-xs text-[#006c4a] font-semibold">Verified Care</span>
        </div>
      </div>

      {/* Available Doctors Section */}
      <section className="mt-1">
        <div className="px-4 py-2 flex items-baseline justify-between">
          <div>
            <h2 className="text-sm font-bold font-heading text-slate-900">
              Available Veterinary Doctors
            </h2>
            <span className="text-[11px] text-slate-400 block">उपलब्ध पशुवैद्यकीय डॉक्टर</span>
          </div>
          <span className="text-xs text-[#ff6b35] font-semibold">{doctors.length} Available</span>
        </div>

        {/* Doctor Cards */}
        <div className="px-4 flex flex-col gap-2.5">
          {doctors.map((doc) => {
            const isSelected = selectedDoctorId === doc.id;
            return (
              <div
                key={doc.id}
                onClick={() => setSelectedDoctorId(doc.id)}
                className={`relative p-3 rounded-2xl cursor-pointer transition-all flex gap-3 items-start ${
                  isSelected
                    ? 'bg-[#ffdbd0]/30 border-l-4 border-l-[#ff6b35] shadow-sm'
                    : 'bg-white border border-slate-100 shadow-xs hover:shadow-sm'
                }`}
              >
                <div className="relative shrink-0">
                  <img
                    src={doc.image}
                    alt={doc.name}
                    className="w-14 h-14 rounded-full object-cover shadow-xs border border-white"
                  />
                  {isSelected && (
                    <div className="absolute -bottom-1 -right-1 bg-[#006c4a] text-white rounded-full w-5 h-5 flex items-center justify-center shadow-xs">
                      <span className="material-symbols-outlined text-[12px]">check</span>
                    </div>
                  )}
                </div>

                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between gap-1">
                    <div>
                      <h3 className="text-xs font-bold font-heading text-slate-900 leading-snug">
                        {doc.name}
                      </h3>
                      <p className="text-[11px] text-slate-400">{doc.nameMr}</p>
                    </div>
                    {isSelected && (
                      <span className="bg-[#ff6b35] text-white text-[10px] px-2 py-0.5 rounded-full shrink-0 shadow-xs flex items-center gap-0.5 font-bold">
                        <span className="material-symbols-outlined text-[12px]">check_circle</span>
                        <span>Selected</span>
                      </span>
                    )}
                  </div>

                  <div className="mt-1 flex flex-wrap items-center gap-1.5">
                    <span className="bg-[#82f5c1]/20 text-[#006c4a] px-2 py-0.5 rounded-full text-[10px] font-semibold">
                      {doc.qualification}
                    </span>
                    <span className="text-[10px] text-[#855300] flex items-center gap-0.5 font-bold">
                      <span className="material-symbols-outlined text-[13px] text-amber-500" style={{ fontVariationSettings: "'FILL' 1" }}>
                        star
                      </span>
                      {doc.rating} ({doc.reviewsCount}+)
                    </span>
                  </div>

                  <div className="mt-2 flex items-center justify-between text-slate-500">
                    <div className="flex items-center gap-1 text-[11px] min-w-0 truncate">
                      <span className="material-symbols-outlined text-[14px] text-[#006c4a] shrink-0">
                        location_on
                      </span>
                      <span className="truncate">{doc.locality} ({doc.distance})</span>
                    </div>
                    <span className="text-xs font-bold text-[#ab3500] ml-2">
                      ₹{visitType === 'home' ? doc.homeVisitFee : doc.clinicFee}
                    </span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* Interactive Booking Form Container */}
      <section className="mx-4 mt-4 p-4 bg-white rounded-2xl shadow-xs border border-slate-100">
        <div className="flex items-center gap-2 pb-2 mb-3 border-b border-slate-100">
          <span className="material-symbols-outlined text-[#ff6b35]">event_note</span>
          <div>
            <h3 className="text-xs font-bold font-heading text-slate-900">
              Schedule Consultation
            </h3>
            <p className="text-[11px] text-slate-400">अपॉइंटमेंट तपशील भरा</p>
          </div>
        </div>

        <form onSubmit={handleBookingSubmit} className="flex flex-col gap-4">
          {/* 1. Pet Type Selection */}
          <div>
            <label className="text-xs font-semibold text-slate-800 block mb-2">
              Select Pet / प्राणी निवडा:
            </label>
            <div className="grid grid-cols-3 gap-2">
              {[
                { key: 'dog', labelEn: 'Dog', labelMr: 'कुत्रा', emoji: '🐶' },
                { key: 'cat', labelEn: 'Cat', labelMr: 'मांजर', emoji: '🐱' },
                { key: 'other', labelEn: 'Other', labelMr: 'इतर', emoji: '🐾' },
              ].map((pet) => {
                const isSelected = selectedPet === pet.key;
                return (
                  <button
                    key={pet.key}
                    type="button"
                    onClick={() => setSelectedPet(pet.key as any)}
                    className={`flex flex-col items-center justify-center p-2.5 rounded-xl transition-all text-center ${
                      isSelected
                        ? 'bg-[#ffdbd0]/50 text-[#5f1900] font-bold shadow-xs border border-[#ff6b35]/30'
                        : 'bg-slate-50 text-slate-700 hover:bg-slate-100 border border-slate-200/50'
                    }`}
                  >
                    <span className="text-2xl mb-1">{pet.emoji}</span>
                    <span className="text-xs">{pet.labelEn}</span>
                    <span className="text-[10px] text-slate-500 font-normal">({pet.labelMr})</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* 2. Date Picker Widget */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="text-xs font-semibold text-slate-800">
                Select Date / तारीख निवडा:
              </label>
              <span className="text-[11px] text-[#006c4a] font-semibold flex items-center gap-1">
                <span className="material-symbols-outlined text-[14px]">calendar_month</span> Oct 2024
              </span>
            </div>

            <div className="grid grid-cols-4 gap-1.5">
              {dateOptions.map((date) => {
                const isSelected = selectedDate.num === date.num;
                return (
                  <button
                    key={date.num}
                    type="button"
                    onClick={() => setSelectedDate(date)}
                    className={`flex flex-col items-center justify-center py-2 px-1 rounded-xl transition-all ${
                      isSelected
                        ? 'bg-[#ff6b35] text-white shadow-xs font-bold scale-102'
                        : 'bg-slate-50 text-slate-700 hover:bg-slate-100 border border-slate-200/50'
                    }`}
                  >
                    <span className={`text-[10px] ${isSelected ? 'opacity-90' : 'text-slate-400'}`}>
                      {date.labelMr}
                    </span>
                    <span className="text-base font-bold font-heading mt-0.5">{date.num}</span>
                    <span className={`text-[10px] ${isSelected ? 'opacity-90 font-semibold' : 'text-slate-400'}`}>
                      {date.day}
                    </span>
                  </button>
                );
              })}
            </div>

            {/* Inline Chosen Date indicator */}
            <div className="mt-2 px-3 py-2 bg-slate-50 rounded-xl flex items-center justify-between text-slate-600 border border-slate-100">
              <div className="flex items-center gap-1.5 text-xs">
                <span className="material-symbols-outlined text-[16px] text-[#ff6b35]">
                  event_available
                </span>
                <span>
                  Chosen Date: <strong className="text-slate-900">{selectedDate.num}/10/2024 ({selectedDate.labelMr})</strong>
                </span>
              </div>
              <span className="text-[11px] text-[#006c4a] font-semibold">Morning &amp; Evening</span>
            </div>
          </div>

          {/* 3. Time Slot Chips */}
          <div>
            <label className="text-xs font-semibold text-slate-800 block mb-2">
              Select Time Slot / वेळ निवडा:
            </label>
            <div className="grid grid-cols-2 gap-2">
              {timeSlots.map((slot) => {
                const isSelected = selectedTime === slot.time;
                return (
                  <button
                    key={slot.time}
                    type="button"
                    onClick={() => setSelectedTime(slot.time)}
                    className={`flex items-center justify-center gap-2 py-2 px-3 rounded-xl text-xs font-semibold transition-all ${
                      isSelected
                        ? 'bg-[#ff6b35] text-white shadow-xs'
                        : 'bg-slate-50 text-slate-700 hover:bg-slate-100 border border-slate-200/50'
                    }`}
                  >
                    <span className="material-symbols-outlined text-[16px]">
                      {slot.icon}
                    </span>
                    <span>{slot.time}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* 4. Consultation Type Toggle */}
          <div>
            <label className="text-xs font-semibold text-slate-800 block mb-2">
              Visit Preference / भेटीचा प्रकार:
            </label>
            <div className="grid grid-cols-2 gap-2 p-1 bg-slate-50 rounded-xl border border-slate-200/50">
              <button
                type="button"
                onClick={() => setVisitType('clinic')}
                className={`flex flex-col items-center justify-center py-2 px-2 rounded-lg transition-all ${
                  visitType === 'clinic'
                    ? 'bg-white text-slate-900 shadow-xs font-bold border border-slate-100'
                    : 'text-slate-500 hover:text-slate-800'
                }`}
              >
                <div className="flex items-center gap-1">
                  <span className="material-symbols-outlined text-[18px] text-[#006c4a]">
                    local_hospital
                  </span>
                  <span className="text-xs">Clinic Visit</span>
                </div>
                <span className="text-[10px] text-slate-400 mt-0.5">
                  क्लिनिक भेट • <strong className="text-[#006c4a]">₹{selectedDoctor.clinicFee}</strong>
                </span>
              </button>

              <button
                type="button"
                onClick={() => setVisitType('home')}
                className={`flex flex-col items-center justify-center py-2 px-2 rounded-lg transition-all ${
                  visitType === 'home'
                    ? 'bg-white text-slate-900 shadow-xs font-bold border border-slate-100'
                    : 'text-slate-500 hover:text-slate-800'
                }`}
              >
                <div className="flex items-center gap-1">
                  <span className="material-symbols-outlined text-[18px] text-[#ff6b35]">
                    home
                  </span>
                  <span className="text-xs">Home Visit</span>
                </div>
                <span className="text-[10px] text-slate-400 mt-0.5">
                  घरी भेट • <strong className="text-[#ab3500]">₹{selectedDoctor.homeVisitFee}</strong>
                </span>
              </button>
            </div>
          </div>

          {/* Fee Breakdown Note */}
          <div className="bg-slate-50 p-3 rounded-xl flex items-center justify-between text-slate-900 border border-slate-100">
            <div className="flex items-center gap-2">
              <span className="material-symbols-outlined text-[18px] text-[#006c4a]">
                receipt_long
              </span>
              <div>
                <span className="text-[11px] text-slate-400 block">Consultation Fee / तपासणी फी</span>
                <span className="text-xs font-bold">
                  {selectedDoctor.name} ({visitType === 'home' ? 'Home Visit' : 'Clinic'})
                </span>
              </div>
            </div>
            <div className="text-right">
              <span className="text-base font-bold text-[#006c4a] block leading-tight">
                ₹{consultationFee}
              </span>
              <span className="text-[10px] text-[#006c4a] block font-medium">No Extra App Fee</span>
            </div>
          </div>

          {/* 5. Submit Button */}
          <button
            type="submit"
            disabled={isSubmitting}
            className="w-full h-12 bg-[#006c4a] hover:bg-[#005137] active:scale-98 text-white rounded-xl text-xs font-bold font-heading shadow-md flex items-center justify-center gap-2 transition-all disabled:opacity-75"
          >
            {isSubmitting ? (
              <>
                <span className="material-symbols-outlined text-[18px] animate-spin">
                  progress_activity
                </span>
                <span>Booking Appointment...</span>
              </>
            ) : (
              <>
                <span className="material-symbols-outlined text-[18px]">check_circle</span>
                <span>Confirm Appointment / अपॉइंटमेंट निश्चित करा</span>
              </>
            )}
          </button>
        </form>
      </section>

      {/* Help & Instant Support Card */}
      <div className="mx-4 mt-4 p-3 bg-[#ffddb8]/30 border border-[#ffddb8] rounded-2xl flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-full bg-[#d68900] text-white flex items-center justify-center shrink-0">
            <span className="material-symbols-outlined text-[20px]">support_agent</span>
          </div>
          <div>
            <p className="text-xs font-bold text-[#492b00] leading-tight">
              Need Immediate Urgent Care?
            </p>
            <p className="text-[10px] text-[#492b00]/80">
              आपत्कालीन संपर्क: Sangli Vet Helpline
            </p>
          </div>
        </div>

        <a
          href="tel:1962"
          onClick={(e) => {
            e.preventDefault();
            alert('Calling Sangli Emergency Animal Helpline: 1962 (आपत्कालीन पशुवैद्यकीय रुग्णवाहिका)...');
          }}
          className="px-3 py-1.5 bg-[#855300] text-white rounded-xl text-xs font-bold flex items-center gap-1 shadow-xs active:scale-95 shrink-0"
        >
          <span className="material-symbols-outlined text-[14px]">call</span>
          <span>Call 1962</span>
        </a>
      </div>
    </div>
  );
};
