import React, { useState } from 'react';
import { AnglePhoto } from '../types';

interface CameraHudScreenProps {
  onBack: () => void;
  onPhotoCaptured: (angleKey: 'front' | 'left' | 'right' | 'paw', photoUrl: string) => void;
  currentAngleIndex: number;
}

export const CameraHudScreen: React.FC<CameraHudScreenProps> = ({
  onBack,
  onPhotoCaptured,
  currentAngleIndex = 0,
}) => {
  const [activeAngleKey, setActiveAngleKey] = useState<'front' | 'left' | 'right' | 'paw'>('front');
  const [flashMode, setFlashMode] = useState<'auto' | 'on' | 'off'>('auto');
  const [guideVisible, setGuideVisible] = useState(true);
  const [petSpecies, setPetSpecies] = useState<'dog' | 'cat'>('dog');
  const [isFlipped, setIsFlipped] = useState(false);
  const [screenFlashing, setScreenFlashing] = useState(false);
  const [capturedCount, setCapturedCount] = useState(1);
  const [successToast, setSuccessToast] = useState<string | null>(null);

  const angleTabs: { key: 'front' | 'left' | 'right' | 'paw'; labelEn: string; labelMr: string; matchText: string }[] = [
    { key: 'front', labelEn: 'Front View', labelMr: 'समोरील', matchText: 'Frontal Pose Match 94%' },
    { key: 'left', labelEn: 'Left Side', labelMr: 'डावी बाजू', matchText: 'Profile Left Alignment • डावी बाजू 91%' },
    { key: 'right', labelEn: 'Right Side', labelMr: 'उजवी बाजू', matchText: 'Profile Right Alignment • उजवी बाजू 88%' },
    { key: 'paw', labelEn: 'Paws View', labelMr: 'पंजे', matchText: 'Lower Paw Framing • पंजे तपासणी 96%' },
  ];

  const currentTab = angleTabs.find((t) => t.key === activeAngleKey) || angleTabs[0];

  const toggleFlash = () => {
    if (flashMode === 'auto') setFlashMode('on');
    else if (flashMode === 'on') setFlashMode('off');
    else setFlashMode('auto');
  };

  const handleShutterClick = () => {
    // Screen flash effect
    setScreenFlashing(true);
    setTimeout(() => setScreenFlashing(false), 120);

    // Save photo
    const sampleCapturedPhoto = '/public/assets/aistudio/Image_12_ae7ded61.jpeg';
    onPhotoCaptured(activeAngleKey, sampleCapturedPhoto);
    setCapturedCount((prev) => Math.min(4, prev + 1));
    setSuccessToast(`Captured ${currentTab.labelEn} (${currentTab.labelMr}) successfully! 📸`);

    // Advance to next angle if not at end
    const nextIndex = (angleTabs.findIndex((t) => t.key === activeAngleKey) + 1) % angleTabs.length;
    setTimeout(() => {
      setActiveAngleKey(angleTabs[nextIndex].key);
      setSuccessToast(null);
    }, 1500);
  };

  return (
    <div className="fixed inset-0 z-50 bg-[#131b2e] flex flex-col justify-between overflow-hidden select-none">
      {/* Viewfinder Main Stage */}
      <div className="relative w-full h-full flex flex-col justify-between overflow-hidden">
        {/* Realistic Camera Live Feed Backdrop */}
        <div
          className={`absolute inset-0 bg-cover bg-center transition-transform duration-500 ${
            isFlipped ? 'scale-x-[-1]' : 'scale-105'
          }`}
          style={{
            backgroundImage: `url('/public/assets/aistudio/Image_12_ae7ded61.jpeg')`,
          }}
        >
          {/* Subtle camera lens vignette and dark dimmer */}
          <div className="absolute inset-0 bg-gradient-to-b from-[#131b2e]/80 via-transparent to-[#131b2e]/90 pointer-events-none" />
          <div className="absolute inset-0 bg-[#131b2e]/20 pointer-events-none" />
        </div>

        {/* Rule of Thirds Minimal Grid Lines */}
        <div className="absolute inset-0 z-10 pointer-events-none grid grid-cols-3 grid-rows-3 opacity-25">
          <div className="border-r border-b border-white/40" />
          <div className="border-r border-b border-white/40" />
          <div className="border-b border-white/40" />
          <div className="border-r border-b border-white/40" />
          <div className="border-r border-b border-white/40" />
          <div className="border-b border-white/40" />
          <div className="border-r border-b border-white/40" />
          <div className="border-r border-b border-white/40" />
          <div />
        </div>

        {/* TOP CONTROL BAR (Camera Settings) */}
        <div className="relative z-20 pt-4 px-4 flex items-center justify-between">
          {/* Back button */}
          <button
            onClick={onBack}
            aria-label="Back to Form"
            className="w-11 h-11 rounded-full bg-white/20 backdrop-blur-md text-white flex items-center justify-center active:scale-95 shadow-md transition-all hover:bg-white/30"
            type="button"
          >
            <span className="material-symbols-outlined text-[24px]">arrow_back</span>
          </button>

          {/* Central Utility Pill (Flash & Silhouette Guide) */}
          <div className="flex items-center gap-1.5 p-1 rounded-full bg-white/20 backdrop-blur-md border border-white/10">
            {/* Flash Switcher */}
            <button
              onClick={toggleFlash}
              className="flex items-center gap-1 px-3 py-1.5 rounded-full text-white active:scale-95 transition-all text-xs font-bold"
              type="button"
            >
              <span className="material-symbols-outlined text-[18px] text-[#ffddb8]">
                {flashMode === 'auto'
                  ? 'flash_auto'
                  : flashMode === 'on'
                  ? 'flash_on'
                  : 'flash_off'}
              </span>
              <span className="uppercase text-[11px]">{flashMode}</span>
            </button>

            <div className="w-px h-4 bg-white/30" />

            {/* Silhouette Guide Toggle */}
            <button
              onClick={() => setGuideVisible(!guideVisible)}
              className={`flex items-center gap-1 px-3 py-1.5 rounded-full transition-all text-xs font-bold ${
                guideVisible
                  ? 'bg-[#ff6b35] text-white shadow-xs'
                  : 'text-white/80 hover:text-white'
              }`}
              type="button"
            >
              <span className="material-symbols-outlined text-[18px]">pets</span>
              <span className="text-[11px]">{guideVisible ? 'Guide On' : 'Guide Off'}</span>
            </button>
          </div>

          {/* Camera Lens Switch (Rear/Front) */}
          <button
            onClick={() => setIsFlipped(!isFlipped)}
            aria-label="Flip Camera"
            className="w-11 h-11 rounded-full bg-white/20 backdrop-blur-md text-white flex items-center justify-center active:scale-90 transition-transform hover:bg-white/30"
            type="button"
          >
            <span
              className={`material-symbols-outlined text-[22px] transition-transform duration-300 ${
                isFlipped ? 'rotate-180' : ''
              }`}
            >
              cameraswitch
            </span>
          </button>
        </div>

        {/* AI SMART HUD & HORIZON LEVEL GAUGE */}
        <div className="relative z-20 flex flex-col items-center gap-2 px-4 mt-2">
          {/* AI Guidance Pill */}
          <div className="flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#131b2e]/85 backdrop-blur-md shadow-lg border border-[#82f5c1]/40">
            <span className="w-2 h-2 rounded-full bg-[#85f8c4] animate-ping" />
            <span className="text-xs text-white tracking-wide font-medium">
              Align pet inside outline • प्राणी रूपरेषेत ठेवा
            </span>
            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-[#006c4a] text-white text-[10px] font-bold">
              <span className="material-symbols-outlined text-[12px]">wb_sunny</span>
              Good Light
            </span>
          </div>

          {/* Level balance bar (0° Level) */}
          <div className="flex items-center gap-2 px-3 py-0.5 rounded-full bg-white/15 backdrop-blur-md">
            <span className="w-6 h-0.5 rounded-full bg-[#85f8c4]" />
            <span className="text-[11px] text-[#85f8c4] font-bold tracking-tight">0° LEVEL</span>
            <span className="w-6 h-0.5 rounded-full bg-[#85f8c4]" />
          </div>
        </div>

        {/* CENTER SILHOUETTE OVERLAY & BRACKETS */}
        <div
          className={`relative z-10 flex-1 flex items-center justify-center pointer-events-none px-4 transition-opacity duration-200 ${
            guideVisible ? 'opacity-100' : 'opacity-0'
          }`}
        >
          <div className="relative w-64 h-72 sm:w-72 sm:h-80 flex items-center justify-center">
            {/* Corner Target Brackets */}
            <div className="absolute -top-1 -left-1 w-6 h-6 border-t-2 border-l-2 border-[#85f8c4] rounded-tl-lg drop-shadow-[0_0_8px_rgba(104,219,169,0.8)]" />
            <div className="absolute -top-1 -right-1 w-6 h-6 border-t-2 border-r-2 border-[#85f8c4] rounded-tr-lg drop-shadow-[0_0_8px_rgba(104,219,169,0.8)]" />
            <div className="absolute -bottom-1 -left-1 w-6 h-6 border-b-2 border-l-2 border-[#85f8c4] rounded-bl-lg drop-shadow-[0_0_8px_rgba(104,219,169,0.8)]" />
            <div className="absolute -bottom-1 -right-1 w-6 h-6 border-b-2 border-r-2 border-[#85f8c4] rounded-br-lg drop-shadow-[0_0_8px_rgba(104,219,169,0.8)]" />

            {/* Center Crosshair reticle */}
            <div className="absolute w-4 h-4 flex items-center justify-center opacity-40">
              <div className="w-full h-px bg-white" />
              <div className="h-full w-px bg-white absolute" />
            </div>

            {/* Dynamic Pet Silhouette Contour (Front Standing Pup Guide) */}
            <svg
              className="w-full h-full filter drop-shadow-[0_0_10px_rgba(130,245,193,0.7)] transition-all duration-300"
              fill="none"
              viewBox="0 0 200 240"
              xmlns="http://www.w3.org/2000/svg"
            >
              <g
                stroke={petSpecies === 'dog' ? '#82f5c1' : '#ffb95f'}
                strokeDasharray="5 5"
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth="2.5"
              >
                {/* Left Ear */}
                <path d="M 70,55 C 50,45 42,75 52,95 C 60,110 70,105 76,96" />
                {/* Right Ear */}
                <path d="M 130,55 C 150,45 158,75 148,95 C 140,110 130,105 124,96" />
                {/* Head Crown */}
                <path d="M 70,55 C 80,42 120,42 130,55" />
                {/* Muzzle / Snout */}
                <path d="M 82,90 C 85,82 115,82 118,90 C 122,102 115,115 100,115 C 85,115 78,102 82,90 Z" />
                {/* Nose Target */}
                <circle
                  cx="100"
                  cy="95"
                  fill={petSpecies === 'dog' ? '#82f5c1' : '#ffb95f'}
                  r="3.5"
                />
                {/* Neck & Chest */}
                <path d="M 64,106 C 54,125 58,155 68,175" />
                <path d="M 136,106 C 146,125 142,155 132,175" />
                {/* Front Left Paw */}
                <path d="M 68,175 L 70,225 C 70,230 84,230 86,225 L 86,180" />
                {/* Front Right Paw */}
                <path d="M 132,175 L 130,225 C 130,230 116,230 114,225 L 114,180" />
                {/* Chest Depth line */}
                <path d="M 86,180 C 95,185 105,185 114,180" />
                {/* Outer Body / Haunches */}
                <path d="M 54,175 C 38,190 38,222 55,225 C 60,226 66,226 70,224" />
                <path d="M 146,175 C 162,190 162,222 145,225 C 140,226 134,226 130,224" />
              </g>
            </svg>

            {/* Dynamic Posture Match Badge */}
            <div className="absolute -bottom-7 bg-white/20 backdrop-blur-md px-3 py-1 rounded-full flex items-center gap-1.5 shadow-sm">
              <span className="material-symbols-outlined text-[14px] text-[#85f8c4]">
                check_circle
              </span>
              <span className="text-[11px] text-white font-semibold">
                {currentTab.matchText}
              </span>
            </div>
          </div>
        </div>

        {/* Micro Notification Feedback */}
        {successToast && (
          <div className="relative z-30 mx-auto px-4 py-1.5 rounded-full bg-emerald-600 text-white text-xs font-bold shadow-lg animate-in fade-in slide-in-from-top duration-200">
            {successToast}
          </div>
        )}

        {/* ANGLE CAROUSEL HUD & PROGRESS */}
        <div className="relative z-20 flex flex-col gap-2 pt-2 pb-2">
          {/* Progress Header */}
          <div className="px-4 flex items-center justify-between text-xs">
            <div className="flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-[#ff6b35]" />
              <span className="text-white font-bold">
                Angle {angleTabs.findIndex((t) => t.key === activeAngleKey) + 1} of 4 • १ पैकी ४ फोटो
              </span>
            </div>
            <span className="text-slate-300 font-medium">Mandatory / आवश्यक</span>
          </div>

          {/* Horizontal Angle Tabs */}
          <div className="flex items-center gap-2 px-4 overflow-x-auto no-scrollbar py-1">
            {angleTabs.map((tab) => {
              const isActive = activeAngleKey === tab.key;
              return (
                <button
                  key={tab.key}
                  onClick={() => setActiveAngleKey(tab.key)}
                  className={`shrink-0 flex items-center gap-1.5 px-3.5 py-1.5 rounded-full text-xs font-semibold transition-all active:scale-95 ${
                    isActive
                      ? 'bg-[#ff6b35] text-white shadow-md'
                      : 'bg-white/20 backdrop-blur-md text-white hover:bg-white/30'
                  }`}
                  type="button"
                >
                  <span className="material-symbols-outlined text-[16px]">
                    {isActive ? 'check_circle' : 'radio_button_unchecked'}
                  </span>
                  <span>
                    {tab.labelEn} ({tab.labelMr})
                  </span>
                </button>
              );
            })}
          </div>
        </div>

        {/* BOTTOM CAMERA DECK & SHUTTER CONTROLS */}
        <div className="relative z-20 w-full bg-[#131b2e]/95 backdrop-blur-xl px-4 pt-4 pb-6 rounded-t-3xl flex flex-col gap-3 shadow-2xl border-t border-white/10">
          <div className="flex items-center justify-between px-3">
            {/* Gallery Thumbnail Preview */}
            <div className="flex flex-col items-center">
              <button
                onClick={() => {
                  alert('Opening Gallery: Selected existing photo for this angle!');
                  handleShutterClick();
                }}
                className="relative w-12 h-12 rounded-xl overflow-hidden bg-white/20 p-0.5 active:scale-95 transition-transform border border-white/20"
                type="button"
              >
                <img
                  src="/public/assets/aistudio/Image_12_ae7ded61.jpeg"
                  alt="Gallery thumbnail"
                  className="w-full h-full object-cover rounded-lg"
                />
                <span className="absolute -top-1.5 -right-1.5 px-1.5 py-0.2 rounded-full bg-[#ff6b35] text-white text-[10px] font-bold shadow-sm">
                  {capturedCount}/4
                </span>
              </button>
              <span className="text-[10px] text-slate-300 mt-1 font-medium">Gallery / गॅलरी</span>
            </div>

            {/* Central Tactile Shutter Button */}
            <div className="flex items-center justify-center">
              <button
                onClick={handleShutterClick}
                aria-label="Capture Angle Photo"
                className="relative w-20 h-20 rounded-full bg-white flex items-center justify-center shadow-[0_0_24px_rgba(255,107,53,0.35)] active:scale-90 transition-transform duration-150 group"
                type="button"
              >
                <div className="absolute inset-1 rounded-full border-2 border-[#ff6b35]/40" />
                <div className="w-14 h-14 rounded-full bg-[#ff6b35] flex items-center justify-center text-white shadow-inner group-hover:bg-[#ab3500] transition-colors">
                  <span className="material-symbols-outlined text-[28px]">photo_camera</span>
                </div>
              </button>
            </div>

            {/* Species Mode Switcher (Dog / Cat switch) */}
            <div className="flex flex-col items-center">
              <button
                onClick={() => setPetSpecies(petSpecies === 'dog' ? 'cat' : 'dog')}
                className="w-12 h-12 rounded-xl bg-white/15 backdrop-blur-md text-white flex items-center justify-center active:scale-95 transition-transform border border-white/20"
                type="button"
              >
                <span className="text-2xl">{petSpecies === 'dog' ? '🐶' : '🐱'}</span>
              </button>
              <span className="text-[10px] text-slate-300 mt-1 font-medium">
                {petSpecies === 'dog' ? 'Dog Guide' : 'Cat Guide'}
              </span>
            </div>
          </div>

          {/* Helpful Pro-Tip Toast Banner */}
          <div className="w-full bg-white/10 backdrop-blur-md rounded-xl p-2.5 flex items-center gap-2.5 border border-white/10">
            <div className="w-7 h-7 rounded-lg bg-[#d68900]/30 flex items-center justify-center shrink-0">
              <span className="material-symbols-outlined text-[#ffddb8] text-[18px]">lightbulb</span>
            </div>
            <p className="text-[11px] leading-tight text-slate-200">
              <strong className="text-[#ffddb8]">Tip:</strong> Keep camera at eye level with your pet (कॅमेरा पाळीव प्राण्याच्या डोळ्यांच्या पातळीवर ठेवा).
            </p>
          </div>

          {/* Save & Finish Button */}
          <button
            onClick={onBack}
            className="w-full py-2.5 rounded-xl bg-[#006c4a] hover:bg-[#005137] text-white font-bold text-xs shadow-md transition-all active:scale-98 flex items-center justify-center gap-1.5"
            type="button"
          >
            <span className="material-symbols-outlined text-[16px]">done_all</span>
            <span>Save Photos &amp; Return to Form (नोंदणीकडे परत जा)</span>
          </button>
        </div>
      </div>

      {/* Visual Camera Flash Animation */}
      <div
        className={`pointer-events-none fixed inset-0 bg-white transition-opacity duration-150 z-50 ${
          screenFlashing ? 'opacity-90' : 'opacity-0'
        }`}
      />
    </div>
  );
};
