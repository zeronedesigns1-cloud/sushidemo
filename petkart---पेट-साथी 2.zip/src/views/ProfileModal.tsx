import React, { useState } from 'react';
import { Appointment } from '../types';

interface ProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
  appointments: Appointment[];
}

export const ProfileModal: React.FC<ProfileModalProps> = ({
  isOpen,
  onClose,
  appointments,
}) => {
  const [language, setLanguage] = useState<'mr' | 'en'>('mr');

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 animate-in fade-in duration-200">
      <div className="bg-white w-full max-w-md rounded-3xl max-h-[90vh] flex flex-col overflow-hidden shadow-2xl">
        {/* Header */}
        <div className="p-4 border-b border-slate-100 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="material-symbols-outlined text-[#ff6b35]">account_circle</span>
            <h3 className="font-bold font-heading text-slate-900 text-base">
              Pet Parent Profile / पाळीव पालक माहिती
            </h3>
          </div>
          <button
            onClick={onClose}
            className="w-9 h-9 rounded-full bg-slate-100 text-slate-600 flex items-center justify-center hover:bg-slate-200"
            type="button"
          >
            <span className="material-symbols-outlined text-[20px]">close</span>
          </button>
        </div>

        {/* Scrollable Body */}
        <div className="overflow-y-auto p-4 space-y-4">
          {/* User Card */}
          <div className="flex items-center gap-3 p-3.5 bg-gradient-to-r from-[#ffdbd0]/50 to-slate-50 rounded-2xl border border-[#ff6b35]/20">
            <img
              src="https://lh3.googleusercontent.com/aida-public/AB6AXuAiQQ6fsbQpgjyg7nBpyO2NzUxX-1hrzB80NRsBQV-YmjpwndS7wu4x3PeDO_dFd4WBOI2xr-gr0F431SA9bMfnsf8QOjUfnMaYit4TCoyjkqU2upkOUUQnwKSdefDNO6VLHeZorSJn8WHENG0BlT0UxjX0UVC8nZu8nwanY2nlyV5ZNm4ruzzbybK7FPfrzIE3kkkHlG7IF8UX3rKsd90hiTcv9TW1ae80AdD-3QYLEKklmVdKD5wo"
              alt="Sushant Pende"
              className="w-14 h-14 rounded-full object-cover ring-2 ring-[#ff6b35]"
            />
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-1.5">
                <h4 className="text-sm font-bold text-slate-900">Sushant Pende</h4>
                <span className="material-symbols-outlined text-[#006c4a] text-[16px]">verified</span>
              </div>
              <p className="text-xs text-slate-500">Vishrambag, Sangli</p>
              <div className="flex items-center gap-2 mt-1 text-[11px] text-slate-600 font-medium">
                <span className="bg-white px-2 py-0.5 rounded-md border border-slate-200">
                  🐾 2 Pets
                </span>
                <span className="bg-white px-2 py-0.5 rounded-md border border-slate-200">
                  ⭐ 4.9 Rating
                </span>
              </div>
            </div>
          </div>

          {/* Language Preference Switch */}
          <div className="p-3 bg-slate-50 rounded-2xl border border-slate-100 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="material-symbols-outlined text-[20px] text-slate-600">translate</span>
              <div>
                <span className="text-xs font-bold text-slate-800 block">App Language / भाषा</span>
                <span className="text-[10px] text-slate-400">Bilingual English + मराठी</span>
              </div>
            </div>

            <div className="flex items-center gap-1 bg-white p-1 rounded-xl border border-slate-200">
              <button
                type="button"
                onClick={() => setLanguage('en')}
                className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all ${
                  language === 'en' ? 'bg-[#ff6b35] text-white shadow-xs' : 'text-slate-600'
                }`}
              >
                English
              </button>
              <button
                type="button"
                onClick={() => setLanguage('mr')}
                className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all ${
                  language === 'mr' ? 'bg-[#ff6b35] text-white shadow-xs' : 'text-slate-600'
                }`}
              >
                मराठी
              </button>
            </div>
          </div>

          {/* Registered Pets in Family */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <h5 className="text-xs font-bold text-slate-800">
                My Fur Family / माझे पाळीव प्राणी
              </h5>
              <span className="text-[10px] text-[#ff6b35] font-bold">+ Add Pet</span>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-100 flex items-center gap-2">
                <span className="text-2xl">🐕</span>
                <div>
                  <p className="text-xs font-bold text-slate-800 leading-tight">Rocky</p>
                  <p className="text-[10px] text-slate-500">Golden Ret. • 2 Yrs</p>
                  <span className="text-[9px] text-[#006c4a] font-semibold">DHPPiL up to date</span>
                </div>
              </div>

              <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-100 flex items-center gap-2">
                <span className="text-2xl">🐱</span>
                <div>
                  <p className="text-xs font-bold text-slate-800 leading-tight">Bella</p>
                  <p className="text-[10px] text-slate-500">Persian Cat • 1 Yr</p>
                  <span className="text-[9px] text-[#006c4a] font-semibold">Dewormed Oct 24</span>
                </div>
              </div>
            </div>
          </div>

          {/* Consultation History */}
          <div className="space-y-2">
            <h5 className="text-xs font-bold text-slate-800">
              Active Bookings / अपॉइंटमेंट्स ({appointments.length})
            </h5>
            {appointments.length === 0 ? (
              <p className="text-xs text-slate-400 italic bg-slate-50 p-3 rounded-xl border border-slate-100">
                No active bookings. Book a consultation in the Vet Care section!
              </p>
            ) : (
              <div className="space-y-2">
                {appointments.map((apt) => (
                  <div
                    key={apt.id}
                    className="p-3 bg-slate-50 rounded-xl border border-slate-100 flex items-center justify-between text-xs"
                  >
                    <div>
                      <p className="font-bold text-slate-900">{apt.doctorName}</p>
                      <p className="text-[11px] text-slate-500">
                        {apt.date} • {apt.timeSlot} ({apt.visitType})
                      </p>
                      <span className="text-[10px] text-[#006c4a] font-bold">
                        Status: Confirmed (नोंदणीकृत)
                      </span>
                    </div>
                    <span className="font-bold text-[#ab3500]">₹{apt.fee}</span>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Sangli Local Support Helpline */}
          <div className="p-3 bg-amber-50 rounded-xl border border-amber-200/60 text-xs text-amber-900 flex items-center justify-between">
            <div>
              <p className="font-bold">Sangli 24x7 Animal Emergency</p>
              <p className="text-[11px] text-amber-700">आपत्कालीन पशु रुग्णवाहिका २४ तास</p>
            </div>
            <a
              href="tel:1962"
              className="px-3 py-1.5 bg-[#855300] text-white font-bold rounded-lg text-xs flex items-center gap-1 shadow-xs"
            >
              <span className="material-symbols-outlined text-[14px]">call</span>
              1962
            </a>
          </div>
        </div>

        {/* Footer */}
        <div className="p-3 bg-slate-50 border-t border-slate-100 text-center">
          <button
            onClick={onClose}
            className="w-full py-2.5 rounded-xl bg-slate-800 hover:bg-slate-900 text-white font-bold text-xs transition-colors"
          >
            Close / बंद करा
          </button>
        </div>
      </div>
    </div>
  );
};
