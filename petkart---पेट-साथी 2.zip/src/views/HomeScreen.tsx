import React, { useState } from 'react';
import { Pet, TabType } from '../types';

interface HomeScreenProps {
  onNavigate: (tab: TabType) => void;
  featuredPets: Pet[];
  onSelectPet: (pet: Pet) => void;
  favorites: string[];
  onToggleFavorite: (petId: string) => void;
  onOpenListingForm: () => void;
}

export const HomeScreen: React.FC<HomeScreenProps> = ({
  onNavigate,
  featuredPets,
  onSelectPet,
  favorites,
  onToggleFavorite,
  onOpenListingForm,
}) => {
  const [activeBanner, setActiveBanner] = useState<number>(0);
  const [searchQuery, setSearchQuery] = useState('');

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      onNavigate('marketplace');
    }
  };

  return (
    <div className="flex flex-col w-full pb-28">
      {/* Top Greeting & Location Context */}
      <section className="px-4 pt-3 pb-2 flex items-center justify-between gap-3 max-w-lg mx-auto w-full">
        <div className="flex flex-col min-w-0">
          <span className="text-xs font-semibold text-slate-800 tracking-tight">
            Welcome Back! 👋 <span className="text-slate-500 font-normal">/ पुन्हा स्वागत आहे!</span>
          </span>
          <h1 className="text-lg font-bold font-heading text-[#ff6b35] truncate mt-0.5">
            Sushant Pende
          </h1>
        </div>

        <div className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-slate-100 text-slate-800 shrink-0 shadow-sm border border-slate-200/50">
          <span className="material-symbols-outlined text-[15px] text-[#006c4a]">location_on</span>
          <span className="text-xs font-semibold">Sangli, MH</span>
        </div>
      </section>

      {/* Interactive Search Bar */}
      <section className="px-4 my-2 max-w-lg mx-auto w-full">
        <form
          onSubmit={handleSearchSubmit}
          className="w-full bg-white rounded-2xl shadow-sm border border-slate-200/70 p-2 flex items-center gap-2 hover:border-[#ff6b35]/50 transition-colors"
        >
          <div className="flex items-center justify-center pl-2 text-slate-400">
            <span className="material-symbols-outlined text-[20px]">search</span>
          </div>
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search pets, food, or doctors... / शोधा..."
            className="w-full bg-transparent text-slate-800 text-xs placeholder:text-slate-400 focus:outline-none"
          />
          <button
            type="button"
            onClick={() => onNavigate('marketplace')}
            aria-label="Filter Options"
            className="w-9 h-9 rounded-xl bg-slate-100 flex items-center justify-center text-[#ff6b35] hover:bg-[#ffdbd0] transition-colors shrink-0"
          >
            <span className="material-symbols-outlined text-[18px]">tune</span>
          </button>
        </form>
      </section>

      {/* Offer Banners Slider / Carousel */}
      <section className="mt-3 max-w-lg mx-auto w-full">
        <div className="flex overflow-x-auto gap-3 px-4 no-scrollbar snap-x snap-mandatory">
          {/* Card 1: Vet Offer */}
          <div
            onClick={() => onNavigate('vetcare')}
            className="min-w-[85vw] xs:min-w-[320px] h-38 rounded-2xl bg-gradient-to-r from-[#ff6b35] to-[#ab3500] p-4 flex flex-col justify-between relative overflow-hidden shadow-md snap-start shrink-0 text-white cursor-pointer active:scale-98 transition-transform"
          >
            {/* Background SVG Motif */}
            <div className="absolute -right-6 -bottom-6 opacity-15 pointer-events-none">
              <svg fill="currentColor" height="140" viewBox="0 0 100 100" width="140">
                <path d="M50 40c7 0 13-6 13-13s-6-13-13-13-13 6-13 13 6 13 13 13zm25 15c6 0 11-5 11-11s-5-11-11-11-11 5-11 11 5 11 11 11zm-50 0c6 0 11-5 11-11s-5-11-11-11-11 5-11 11 5 11 11 11zm25 12c-15 0-27 10-27 23 0 6 5 10 11 10 6 0 10-4 16-4s10 4 16 4c6 0 11-4 11-10 0-13-12-23-27-23z" />
              </svg>
            </div>

            <div className="flex items-center gap-2 z-10">
              <span className="px-2 py-0.5 rounded-full bg-white/20 backdrop-blur-sm text-[10px] font-bold uppercase tracking-wider text-white">
                Special Offer
              </span>
            </div>

            <div className="z-10">
              <h2 className="text-base font-bold font-heading leading-snug drop-shadow-sm">
                Get 20% OFF on First Vet Visit! 🩺
              </h2>
              <p className="text-xs opacity-90 mt-0.5 font-medium">
                पहिल्या डॉक्टर भेटीवर २०% सूट!
              </p>
            </div>

            <div className="flex items-center justify-between z-10 pt-1">
              <span className="bg-white text-[#ab3500] px-3 py-1 rounded-full text-xs font-bold shadow-sm flex items-center gap-1">
                Claim Now
                <span className="material-symbols-outlined text-[14px]">arrow_forward</span>
              </span>
              <span className="text-[10px] bg-black/25 px-2 py-0.5 rounded font-mono font-bold">
                CODE: FIRSTVET
              </span>
            </div>
          </div>

          {/* Card 2: Food & Supplies Offer */}
          <div
            onClick={() => onNavigate('shop')}
            className="min-w-[85vw] xs:min-w-[320px] h-38 rounded-2xl bg-gradient-to-r from-[#006c4a] to-[#00714e] p-4 flex flex-col justify-between relative overflow-hidden shadow-md snap-start shrink-0 text-white cursor-pointer active:scale-98 transition-transform"
          >
            <div className="flex items-center gap-2 z-10">
              <span className="px-2 py-0.5 rounded-full bg-white/20 backdrop-blur-sm text-[10px] font-bold uppercase tracking-wider text-white">
                Express Delivery
              </span>
            </div>

            <div className="z-10">
              <h2 className="text-base font-bold font-heading leading-snug drop-shadow-sm">
                Free Home Delivery on Pet Food 🦴
              </h2>
              <p className="text-xs opacity-90 mt-0.5 font-medium">
                खाद्यावर मोफत ३०-मिनिटांत होम डिलिव्हरी
              </p>
            </div>

            <div className="flex items-center justify-between z-10 pt-1">
              <span className="bg-white text-[#006c4a] px-3 py-1 rounded-full text-xs font-bold shadow-sm flex items-center gap-1">
                Shop Now
                <span className="material-symbols-outlined text-[14px]">shopping_cart</span>
              </span>
              <span className="text-[10px] bg-black/25 px-2 py-0.5 rounded font-mono font-bold">
                CODE: FREESHIP
              </span>
            </div>
          </div>
        </div>

        {/* Carousel Dots */}
        <div className="flex justify-center gap-1.5 mt-2.5">
          <span className="w-4 h-1.5 rounded-full bg-[#ff6b35]" />
          <span className="w-1.5 h-1.5 rounded-full bg-slate-300" />
        </div>
      </section>

      {/* Quick Categories */}
      <section className="mt-5 max-w-lg mx-auto w-full">
        <div className="px-4 flex items-baseline justify-between mb-2">
          <h2 className="text-sm font-bold font-heading text-slate-800">
            Categories <span className="text-slate-400 font-normal text-xs">/ वर्गवारी</span>
          </h2>
          <span className="text-xs text-[#006c4a] font-semibold">4 Services in Sangli</span>
        </div>

        <div className="grid grid-cols-4 gap-2 px-4">
          {/* Category 1: Pets */}
          <button
            onClick={() => onNavigate('marketplace')}
            className="flex flex-col items-center gap-1 p-2 rounded-2xl bg-white border border-slate-100 shadow-sm hover:border-[#ff6b35]/40 transition-all active:scale-95 group"
            type="button"
          >
            <div className="w-12 h-12 rounded-xl bg-[#ffdbd0] flex items-center justify-center text-[#ab3500] shadow-xs group-hover:scale-105 transition-transform">
              <span className="material-symbols-outlined text-[24px]">pets</span>
            </div>
            <div className="text-center">
              <span className="text-xs font-bold text-slate-800 block leading-tight">Pets</span>
              <span className="text-[10px] text-slate-400 block">प्राणी</span>
            </div>
          </button>

          {/* Category 2: Shop */}
          <button
            onClick={() => onNavigate('shop')}
            className="flex flex-col items-center gap-1 p-2 rounded-2xl bg-white border border-slate-100 shadow-sm hover:border-[#ff6b35]/40 transition-all active:scale-95 group"
            type="button"
          >
            <div className="w-12 h-12 rounded-xl bg-[#ffddb8] flex items-center justify-center text-[#855300] shadow-xs group-hover:scale-105 transition-transform">
              <span className="material-symbols-outlined text-[24px]">shopping_bag</span>
            </div>
            <div className="text-center">
              <span className="text-xs font-bold text-slate-800 block leading-tight">Shop</span>
              <span className="text-[10px] text-slate-400 block">खरेदी</span>
            </div>
          </button>

          {/* Category 3: Vet Care */}
          <button
            onClick={() => onNavigate('vetcare')}
            className="flex flex-col items-center gap-1 p-2 rounded-2xl bg-white border border-slate-100 shadow-sm hover:border-[#ff6b35]/40 transition-all active:scale-95 group"
            type="button"
          >
            <div className="w-12 h-12 rounded-xl bg-[#82f5c1] flex items-center justify-center text-[#006c4a] shadow-xs group-hover:scale-105 transition-transform">
              <span className="material-symbols-outlined text-[24px]">stethoscope</span>
            </div>
            <div className="text-center">
              <span className="text-xs font-bold text-slate-800 block leading-tight">Vet Care</span>
              <span className="text-[10px] text-slate-400 block">डॉक्टर</span>
            </div>
          </button>

          {/* Category 4: Sell/Post */}
          <button
            onClick={onOpenListingForm}
            className="flex flex-col items-center gap-1 p-2 rounded-2xl bg-white border border-slate-100 shadow-sm hover:border-[#ff6b35]/40 transition-all active:scale-95 group"
            type="button"
          >
            <div className="w-12 h-12 rounded-xl bg-[#dae2fd] flex items-center justify-center text-[#131b2e] shadow-xs group-hover:scale-105 transition-transform">
              <span className="material-symbols-outlined text-[24px]">add_a_photo</span>
            </div>
            <div className="text-center">
              <span className="text-xs font-bold text-slate-800 block leading-tight">Post Ad</span>
              <span className="text-[10px] text-slate-400 block">नोंदणी</span>
            </div>
          </button>
        </div>
      </section>

      {/* Featured Pets Horizontal Carousel */}
      <section className="mt-6 max-w-lg mx-auto w-full">
        <div className="px-4 flex items-center justify-between mb-2.5">
          <h2 className="text-sm font-bold font-heading text-slate-800">
            Featured Pets <span className="text-slate-400 font-normal text-xs">/ वैशिष्ट्यीकृत प्राणी</span>
          </h2>
          <button
            onClick={() => onNavigate('marketplace')}
            className="text-xs font-bold text-[#ff6b35] hover:underline flex items-center"
            type="button"
          >
            See All / सर्व पहा
            <span className="material-symbols-outlined text-[16px] ml-0.5">chevron_right</span>
          </button>
        </div>

        <div className="flex overflow-x-auto gap-3 px-4 pb-2 no-scrollbar snap-x">
          {featuredPets.map((pet) => {
            const isFav = favorites.includes(pet.id);
            return (
              <div
                key={pet.id}
                onClick={() => onSelectPet(pet)}
                className="w-[165px] bg-white rounded-2xl border border-slate-100 shadow-xs flex flex-col overflow-hidden snap-start shrink-0 hover:shadow-md transition-shadow relative cursor-pointer"
              >
                {/* Favorite button */}
                <button
                  aria-label="Add to favorites"
                  onClick={(e) => {
                    e.stopPropagation();
                    onToggleFavorite(pet.id);
                  }}
                  className="absolute top-2 right-2 w-7 h-7 rounded-full bg-white/85 backdrop-blur-md flex items-center justify-center text-slate-500 z-10 hover:text-red-500 transition-colors shadow-sm"
                  type="button"
                >
                  <span
                    className={`material-symbols-outlined text-[16px] ${
                      isFav ? 'text-red-500' : ''
                    }`}
                    style={{ fontVariationSettings: isFav ? "'FILL' 1" : "'FILL' 0" }}
                  >
                    favorite
                  </span>
                </button>

                {/* Adoption Badge */}
                {pet.isAdoption && (
                  <span className="absolute top-2 left-2 z-10 bg-[#006c4a] text-white text-[9px] px-2 py-0.5 rounded-full font-bold shadow-sm">
                    ADOPT
                  </span>
                )}

                <div className="w-full h-32 relative bg-slate-100 overflow-hidden">
                  <img
                    src={pet.images[0]}
                    alt={pet.name}
                    className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
                  />
                </div>

                <div className="p-3 flex flex-col justify-between flex-1">
                  <div>
                    <h3 className="text-xs font-bold font-heading text-slate-800 truncate">
                      {pet.name}
                    </h3>
                    <p className="text-[11px] text-slate-400 mt-0.5 truncate">
                      {pet.age} • {pet.gender}
                    </p>
                  </div>

                  <div className="mt-2.5 flex items-center justify-between">
                    <span className="text-xs font-black text-[#ab3500]">
                      {pet.isAdoption ? 'Free Adoption' : `₹${pet.price.toLocaleString('en-IN')}`}
                    </span>
                    <span className="w-6 h-6 rounded-full bg-[#ffdbd0] flex items-center justify-center text-[#ab3500]">
                      <span className="material-symbols-outlined text-[14px]">chevron_right</span>
                    </span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* Hyperlocal Verified Trust Banner */}
      <section className="px-4 mt-6 max-w-lg mx-auto w-full">
        <div className="p-4 rounded-2xl bg-[#eaedff] border border-indigo-100/70 flex items-center gap-3">
          <div className="w-11 h-11 rounded-xl bg-[#006c4a] flex items-center justify-center text-white shrink-0 shadow-sm">
            <span className="material-symbols-outlined text-[22px]">verified</span>
          </div>
          <div className="flex-1 min-w-0">
            <h4 className="text-xs font-bold text-slate-900 leading-snug">
              100% Certified Care in Sangli
            </h4>
            <p className="text-[11px] text-slate-600 mt-0.5">
              सत्यापित पशुवैद्य आणि निरोगी प्राणी हमी. Vishrambag, Ganpati Peth &amp; Kupwad certified partners.
            </p>
          </div>
        </div>
      </section>

      {/* Floating Sell/Adopt Pet button */}
      <div className="fixed bottom-20 right-4 z-30">
        <button
          onClick={onOpenListingForm}
          className="inline-flex items-center gap-2 bg-gradient-to-r from-[#ff6b35] to-[#ab3500] text-white pl-3.5 pr-4 py-2.5 rounded-full shadow-lg shadow-[#ff6b35]/40 hover:scale-102 active:scale-95 transition-all group"
          type="button"
        >
          <div className="w-7 h-7 rounded-full bg-white/20 flex items-center justify-center shrink-0">
            <span className="material-symbols-outlined text-[18px] text-white">
              add_a_photo
            </span>
          </div>
          <div className="flex flex-col text-left">
            <span className="text-xs font-bold font-heading leading-tight">
              Sell / Adopt Pet
            </span>
            <span className="text-[10px] text-[#ffdbd0] leading-tight">
              प्राणी विका किंवा दत्तक द्या
            </span>
          </div>
        </button>
      </div>
    </div>
  );
};
