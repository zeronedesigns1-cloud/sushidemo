import React, { useState } from 'react';
import { AnglePhoto, Pet } from '../types';
import { SANGLI_LOCALITIES } from '../data/mockData';

interface ListingFormScreenProps {
  onBack: () => void;
  onOpenCameraHud: (angleKey: 'front' | 'left' | 'right' | 'paw') => void;
  onPublishPet: (pet: Pet) => void;
  anglePhotos: Record<string, string>;
}

export const ListingFormScreen: React.FC<ListingFormScreenProps> = ({
  onBack,
  onOpenCameraHud,
  onPublishPet,
  anglePhotos,
}) => {
  const [listingType, setListingType] = useState<'sell' | 'adopt'>('sell');
  const [category, setCategory] = useState<'dogs' | 'cats' | 'birds' | 'other'>('dogs');
  const [petName, setPetName] = useState('Bruno');
  const [breed, setBreed] = useState('Golden Retriever');
  const [ageValue, setAgeValue] = useState('3');
  const [ageUnit, setAgeUnit] = useState('Months');
  const [gender, setGender] = useState<'Male' | 'Female'>('Male');
  const [price, setPrice] = useState('12000');
  const [isNegotiable, setIsNegotiable] = useState(true);
  const [locality, setLocality] = useState('vishrambag');
  const [notes, setNotes] = useState('Friendly with kids, potty trained, active and playful... (मुलांशी मैत्रीपूर्ण, खेळकर...)');
  const [contactPref, setContactPref] = useState<'call_wa' | 'chat_only'>('call_wa');
  const [vaccineCardUploaded, setVaccineCardUploaded] = useState(true);
  const [dewormingDate, setDewormingDate] = useState('2024-05-15');
  const [kciUploaded, setKciUploaded] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submittedMessage, setSubmittedMessage] = useState(false);

  const angleConfig: { key: 'front' | 'left' | 'right' | 'paw'; labelEn: string; labelMr: string; icon: string }[] = [
    { key: 'front', labelEn: 'Front View', labelMr: 'समोरील', icon: 'check_circle' },
    { key: 'left', labelEn: 'Left Side', labelMr: 'डावी बाजू', icon: 'add_a_photo' },
    { key: 'right', labelEn: 'Right Side', labelMr: 'उजवी बाजू', icon: 'add_a_photo' },
    { key: 'paw', labelEn: 'Paw View', labelMr: 'पंजे', icon: 'pets' },
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    const newPet: Pet = {
      id: `pet-user-${Date.now()}`,
      name: petName || 'Pet',
      nameMr: `${petName} (नोंदणीकृत)`,
      category: category === 'dogs' ? 'puppies' : category === 'cats' ? 'kittens' : 'other',
      breed: breed,
      breedMr: breed,
      age: `${ageValue} ${ageUnit}`,
      ageMr: `${ageValue} ${ageUnit === 'Months' ? 'महिने' : 'वर्षे'}`,
      gender: gender,
      genderMr: gender === 'Male' ? 'नर' : 'मादी',
      location: `${locality.toUpperCase()}, Sangli`,
      localityMr: locality,
      price: listingType === 'adopt' ? 0 : parseInt(price) || 0,
      isAdoption: listingType === 'adopt',
      images: [
        anglePhotos['front'] || 'https://lh3.googleusercontent.com/aida-public/AB6AXuBen7lAilvcWCHahZMKfed7PYUhDIpZJ0qGjt7nytgBGdQRUdrkcgyhgOpEDc7Oe8Aix9s-WzqaSo3DkT7_ZEirIMN1X_GPrHCjnQctVABHHg3mf1HsUpffF3f1K83DYjacPNw2JoXnXTntJe8Vtv2P-mvfwas99GKK1pjUZaHFqUS-QYf9J3Wf2krxG1jRz0NraEVh2kJ3Qco7cjFi-hhpL3S9RxaLi3vieD6NWkgxjqkQzeONq2A1',
        '/public/assets/aistudio/Image_12_ae7ded61.jpeg',
      ],
      badges: listingType === 'adopt' ? ['Free Adoption', 'Verified Vet Stamp'] : ['Verified Seller', 'Vaccinated'],
      description: notes || 'Authentic listing from Sangli parent.',
      descriptionMr: notes || 'सांगलीमधील खात्रीशीर पाळीव प्राणी.',
      sellerName: 'Sushant Pende (You)',
      sellerPhone: '+91 98230 77112',
      isVaccinated: vaccineCardUploaded,
      isDewormed: true,
      isKciRegistered: kciUploaded,
      rating: 5.0,
    };

    setTimeout(() => {
      setIsSubmitting(false);
      setSubmittedMessage(true);
      setTimeout(() => {
        onPublishPet(newPet);
      }, 1200);
    }, 1000);
  };

  return (
    <div className="flex flex-col w-full min-h-screen bg-[#faf8ff] pb-32 max-w-lg mx-auto">
      {/* Top Header */}
      <header className="sticky top-0 w-full z-40 bg-white/95 backdrop-blur-xl border-b border-slate-100 shadow-xs">
        <div className="h-16 px-4 flex items-center justify-between gap-3">
          <div className="flex items-center gap-2 min-w-0">
            <button
              onClick={onBack}
              aria-label="Go back"
              className="w-10 h-10 -ml-1 flex items-center justify-center rounded-full text-slate-700 hover:bg-slate-100 transition-colors"
              type="button"
            >
              <span className="material-symbols-outlined text-[24px]">arrow_back</span>
            </button>
            <div className="flex flex-col truncate">
              <h1 className="text-sm font-bold font-heading text-slate-900 truncate">
                Sell Or Adopt Pet Listing Form
              </h1>
              <span className="text-[11px] text-slate-500 font-medium flex items-center gap-1">
                <span className="material-symbols-outlined text-[13px] text-[#006c4a]">location_on</span>
                Sangli • सांगली
              </span>
            </div>
          </div>
          <button
            onClick={onBack}
            className="w-9 h-9 rounded-full bg-slate-100 flex items-center justify-center text-slate-600 hover:bg-slate-200"
            type="button"
          >
            <span className="material-symbols-outlined text-[20px]">close</span>
          </button>
        </div>
      </header>

      <form onSubmit={handleSubmit} className="flex flex-col w-full">
        {/* Step 1 of 2 Banner */}
        <section className="px-4 pt-3 pb-2">
          <div className="bg-[#f2f3ff] rounded-2xl p-4 shadow-xs relative overflow-hidden border border-indigo-50">
            <div className="flex items-center justify-between gap-3 relative z-10">
              <div className="flex items-center gap-3 min-w-0">
                <div className="w-10 h-10 rounded-xl bg-[#ff6b35]/15 flex items-center justify-center shrink-0 text-[#ff6b35]">
                  <span className="material-symbols-outlined text-[24px]">pets</span>
                </div>
                <div className="min-w-0">
                  <div className="flex items-center gap-1.5">
                    <span className="text-[10px] bg-[#82f5c1] text-[#00714e] px-2 py-0.5 rounded-full font-bold">
                      Step 1 of 2
                    </span>
                    <span className="text-xs text-slate-500">• Quick Post / झटपट नोंदणी</span>
                  </div>
                  <p className="text-sm font-bold text-slate-900 truncate mt-0.5">
                    Find loving homes in Sangli
                  </p>
                </div>
              </div>
              <div className="shrink-0 text-right">
                <span className="text-sm font-bold text-[#ff6b35]">95%</span>
                <p className="text-[10px] text-slate-400">Response</p>
              </div>
            </div>

            {/* Progress Bar Track */}
            <div className="w-full bg-slate-200 h-1.5 rounded-full mt-3 overflow-hidden">
              <div className="bg-[#ff6b35] h-full rounded-full w-2/3" />
            </div>
          </div>
        </section>

        {/* 1. Listing Type Segmented Switch */}
        <section className="px-4 pt-2">
          <div className="bg-white p-1.5 rounded-2xl shadow-xs border border-slate-100 flex items-center gap-1.5">
            <button
              type="button"
              onClick={() => setListingType('sell')}
              className={`flex-1 py-3 px-3 rounded-xl flex items-center justify-center gap-2 transition-all ${
                listingType === 'sell'
                  ? 'bg-[#ff6b35] text-white shadow-sm'
                  : 'text-slate-700 hover:bg-slate-50'
              }`}
            >
              <span className="material-symbols-outlined text-[20px]" style={{ fontVariationSettings: "'FILL' 1" }}>
                sell
              </span>
              <div className="text-left leading-tight">
                <p className="text-xs font-bold font-heading">Sell Pet</p>
                <p className="text-[10px] opacity-90">विक्री करा</p>
              </div>
            </button>

            <button
              type="button"
              onClick={() => setListingType('adopt')}
              className={`flex-1 py-3 px-3 rounded-xl flex items-center justify-center gap-2 transition-all ${
                listingType === 'adopt'
                  ? 'bg-[#ba1a1a] text-white shadow-sm'
                  : 'text-slate-700 hover:bg-slate-50'
              }`}
            >
              <span className="material-symbols-outlined text-[20px]" style={{ fontVariationSettings: "'FILL' 1" }}>
                volunteer_activism
              </span>
              <div className="text-left leading-tight">
                <div className="flex items-center gap-1">
                  <p className="text-xs font-bold font-heading">Adopt Free</p>
                  <span className="bg-[#ffdad6] text-[#93000a] text-[9px] px-1.5 rounded-full font-bold uppercase">
                    मोफत
                  </span>
                </div>
                <p className="text-[10px] opacity-90">दत्तक द्या</p>
              </div>
            </button>
          </div>
        </section>

        {/* 2. Photo Upload Gallery (4 Mandatory Angles) */}
        <section className="px-4 pt-4">
          <div className="bg-white rounded-2xl p-4 shadow-xs border border-slate-100 space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-sm font-bold font-heading text-slate-900">
                  Pet Mandatory Angle Photos{' '}
                  <span className="text-xs text-slate-500 font-normal">/ सर्व बाजूंनी फोटो</span>
                </h2>
                <p className="text-xs text-slate-400 mt-0.5">
                  Upload 4 mandatory angles: Front, Left side, Right side, Paw (समोरील, डावी, उजवी बाजू आणि पंजे)
                </p>
              </div>
              <span className="text-[10px] bg-[#ffdbd0] text-[#832600] px-2 py-0.5 rounded-full font-bold shrink-0">
                4 Required Angles
              </span>
            </div>

            {/* 4 Angle Grid */}
            <div className="grid grid-cols-2 gap-2.5 pt-1">
              {angleConfig.map((angle) => {
                const photoUrl = anglePhotos[angle.key];
                return (
                  <div key={angle.key}>
                    {photoUrl ? (
                      /* Uploaded Preview State */
                      <div className="relative rounded-xl overflow-hidden bg-slate-100 border border-[#ff6b35]/30 flex flex-col aspect-[4/3] group shadow-xs">
                        <img
                          src={photoUrl}
                          alt={angle.labelEn}
                          className="w-full h-full object-cover"
                        />
                        <div className="absolute top-1.5 left-1.5 bg-white/95 backdrop-blur-sm text-[#ab3500] text-[10px] px-1.5 py-0.5 rounded font-bold flex items-center gap-1 shadow-xs">
                          <span className="material-symbols-outlined text-[12px]">check_circle</span>
                          {angle.labelEn}
                        </div>
                        <button
                          type="button"
                          onClick={() => onOpenCameraHud(angle.key)}
                          className="absolute top-1.5 right-1.5 w-6 h-6 rounded-full bg-black/60 text-white flex items-center justify-center hover:bg-[#ba1a1a] transition-colors"
                          title="Retake photo"
                        >
                          <span className="material-symbols-outlined text-[14px]">edit</span>
                        </button>
                        <div className="absolute bottom-0 inset-x-0 bg-white/95 px-2 py-1 flex items-center justify-between text-[10px]">
                          <span className="font-bold text-slate-800 truncate">{angle.labelEn}</span>
                          <span className="text-[#006c4a] font-bold shrink-0">Uploaded</span>
                        </div>
                      </div>
                    ) : (
                      /* Empty Angle Upload Button */
                      <button
                        type="button"
                        onClick={() => onOpenCameraHud(angle.key)}
                        className="w-full relative rounded-xl bg-slate-50 hover:bg-slate-100 flex flex-col items-center justify-center p-3 cursor-pointer transition-all aspect-[4/3] text-center border border-dashed border-slate-300 hover:border-[#ff6b35] active:scale-98 group"
                      >
                        <div className="w-8 h-8 rounded-full bg-[#ffdbd0] group-hover:scale-110 flex items-center justify-center text-[#ab3500] mb-1 transition-transform">
                          <span className="material-symbols-outlined text-[18px]">add_a_photo</span>
                        </div>
                        <span className="text-xs font-bold text-slate-800 leading-tight">
                          {angle.labelEn} / {angle.labelMr}
                        </span>
                        <span className="text-[10px] font-semibold text-[#ab3500] mt-0.5">
                          Mandatory / आवश्यक
                        </span>
                      </button>
                    )}
                  </div>
                );
              })}
            </div>

            {/* Trust Helper Notice */}
            <div className="mt-2 p-2.5 bg-[#82f5c1]/25 rounded-xl flex items-center gap-2 text-xs text-[#005137] border border-[#82f5c1]/40">
              <span className="material-symbols-outlined text-[#006c4a] text-[20px] shrink-0" style={{ fontVariationSettings: "'FILL' 1" }}>
                verified_user
              </span>
              <p className="leading-tight">
                <strong className="text-[#006c4a]">Buyer Protection:</strong> Clean photos from all 4 angles build 100% buyer trust &amp; prevent fraud. ४ बाजूंनी स्पष्ट फोटो विश्वासार्हता वाढवतात.
              </p>
            </div>
          </div>
        </section>

        {/* 3. Basic Information */}
        <section className="px-4 pt-4">
          <div className="bg-white rounded-2xl p-4 shadow-xs border border-slate-100 space-y-4">
            <div>
              <h2 className="text-sm font-bold font-heading text-slate-900">
                Basic Information <span className="text-xs text-slate-500 font-normal">/ मूलभूत माहिती</span>
              </h2>
              <p className="text-xs text-slate-400">Provide authentic details to assist adopters &amp; buyers</p>
            </div>

            {/* Category Filter Chips */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-2">
                Pet Category / प्राण्याचा प्रकार *
              </label>
              <div className="grid grid-cols-4 gap-2">
                {[
                  { key: 'dogs', labelEn: 'Dog', labelMr: 'कुत्रा', icon: 'sound_detection_dog_barking' },
                  { key: 'cats', labelEn: 'Cat', labelMr: 'मांजर', icon: 'cruelty_free' },
                  { key: 'birds', labelEn: 'Birds', labelMr: 'पक्षी', icon: 'flutter' },
                  { key: 'other', labelEn: 'Other', labelMr: 'इतर', icon: 'category' },
                ].map((item) => (
                  <button
                    key={item.key}
                    type="button"
                    onClick={() => setCategory(item.key as any)}
                    className={`py-2 px-1 rounded-xl flex flex-col items-center justify-center gap-1 transition-all ${
                      category === item.key
                        ? 'bg-[#ff6b35] text-white font-bold shadow-xs'
                        : 'bg-slate-50 text-slate-700 hover:bg-slate-100 border border-slate-200/50'
                    }`}
                  >
                    <span className="material-symbols-outlined text-[18px]">{item.icon}</span>
                    <span className="text-[11px] leading-tight">
                      {item.labelEn} / {item.labelMr}
                    </span>
                  </button>
                ))}
              </div>
            </div>

            {/* Pet Name & Breed Input */}
            <div className="space-y-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1" htmlFor="pet-name">
                  Pet Name or Title / नाव किंवा शीर्षक *
                </label>
                <div className="relative">
                  <input
                    id="pet-name"
                    type="text"
                    value={petName}
                    onChange={(e) => setPetName(e.target.value)}
                    placeholder="e.g. Bruno (ब्रूनो)"
                    required
                    className="w-full h-11 bg-slate-50 border border-slate-200 rounded-xl px-3.5 text-xs text-slate-900 outline-none focus:border-[#ff6b35] focus:bg-white transition-colors"
                  />
                  <span className="absolute right-3 top-3 material-symbols-outlined text-[#ff6b35] text-[18px]">
                    verified
                  </span>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1" htmlFor="pet-breed">
                  Breed / प्राण्याची जात *
                </label>
                <div className="relative">
                  <select
                    id="pet-breed"
                    value={breed}
                    onChange={(e) => setBreed(e.target.value)}
                    className="w-full h-11 bg-slate-50 border border-slate-200 rounded-xl px-3.5 pr-8 appearance-none text-xs text-slate-900 outline-none focus:border-[#ff6b35] focus:bg-white transition-colors"
                  >
                    <option value="Golden Retriever">Golden Retriever (गोल्डन रिट्रीव्हर)</option>
                    <option value="Indian Pariah / Indie">Indian Pariah / Indie (देशी / गावठी)</option>
                    <option value="Labrador Retriever">Labrador Retriever (लॅब्राडोर)</option>
                    <option value="German Shepherd">German Shepherd (जर्मन शेफर्ड)</option>
                    <option value="Persian Cat">Persian Cat (पर्शियन मांजर)</option>
                    <option value="Beagle">Beagle (बीगल)</option>
                    <option value="Other">Other Unique Breed (इतर)</option>
                  </select>
                  <span className="absolute right-3 top-3 material-symbols-outlined text-slate-400 pointer-events-none text-[20px]">
                    arrow_drop_down
                  </span>
                </div>
              </div>
            </div>

            {/* Age & Gender Grid */}
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Age / वय *
                </label>
                <div className="flex items-center gap-1.5">
                  <input
                    type="number"
                    min="0"
                    max="25"
                    value={ageValue}
                    onChange={(e) => setAgeValue(e.target.value)}
                    className="w-16 h-11 bg-slate-50 border border-slate-200 rounded-xl text-center text-xs font-bold text-slate-900 outline-none focus:border-[#ff6b35]"
                  />
                  <select
                    value={ageUnit}
                    onChange={(e) => setAgeUnit(e.target.value)}
                    className="flex-1 h-11 bg-slate-50 border border-slate-200 rounded-xl px-2 text-xs text-slate-800 outline-none"
                  >
                    <option value="Months">Months / महिने</option>
                    <option value="Years">Years / वर्षे</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Gender / लिंग *
                </label>
                <div className="grid grid-cols-2 gap-1.5">
                  <button
                    type="button"
                    onClick={() => setGender('Male')}
                    className={`h-11 rounded-xl text-xs font-bold flex items-center justify-center gap-1 transition-all ${
                      gender === 'Male'
                        ? 'bg-[#ff6b35] text-white shadow-xs'
                        : 'bg-slate-50 text-slate-700 border border-slate-200'
                    }`}
                  >
                    <span className="material-symbols-outlined text-[15px]">male</span>
                    <span>Male (नर)</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setGender('Female')}
                    className={`h-11 rounded-xl text-xs font-bold flex items-center justify-center gap-1 transition-all ${
                      gender === 'Female'
                        ? 'bg-[#ff6b35] text-white shadow-xs'
                        : 'bg-slate-50 text-slate-700 border border-slate-200'
                    }`}
                  >
                    <span className="material-symbols-outlined text-[15px]">female</span>
                    <span>Female (मादी)</span>
                  </button>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* 4. Health Documents & Certificates */}
        <section className="px-4 pt-4">
          <div className="bg-white rounded-2xl p-4 shadow-xs border border-slate-100 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-emerald-100 flex items-center justify-center text-[#006c4a]">
                  <span className="material-symbols-outlined text-[20px]" style={{ fontVariationSettings: "'FILL' 1" }}>
                    health_and_safety
                  </span>
                </div>
                <div>
                  <h2 className="text-sm font-bold font-heading text-slate-900">
                    Health Documents &amp; Certificates
                  </h2>
                  <p className="text-[11px] text-slate-400">आरोग्य कागदपत्रे व प्रमाणपत्रे</p>
                </div>
              </div>
              <span className="text-[10px] bg-emerald-100 text-[#00714e] px-2 py-0.5 rounded-full font-bold flex items-center gap-1 shrink-0">
                <span className="material-symbols-outlined text-[12px]">verified</span> Verified Badge
              </span>
            </div>

            {/* 1. Vaccination Card */}
            <div className="p-3 rounded-xl bg-slate-50 border border-emerald-200/60 flex flex-col gap-2">
              <div className="flex items-start justify-between gap-2">
                <div className="flex items-start gap-2 min-w-0">
                  <div className="w-8 h-8 rounded-full bg-emerald-100 flex items-center justify-center text-[#006c4a] shrink-0 mt-0.5">
                    <span className="material-symbols-outlined text-[18px]">vaccines</span>
                  </div>
                  <div>
                    <p className="text-xs font-bold text-slate-900 leading-tight">
                      Vaccination Card / लस प्रमाणपत्र (Card/Booklet)
                    </p>
                    <p className="text-[11px] text-slate-500">Core DHPPiL or Rabies shots record</p>
                  </div>
                </div>
                <span className="text-[10px] bg-emerald-100 text-[#006c4a] px-2 py-0.5 rounded-full font-bold flex items-center gap-1 shrink-0">
                  <span className="material-symbols-outlined text-[12px]">check</span> Verified Vet Stamp
                </span>
              </div>

              <div className="flex items-center justify-between pt-1 gap-2 text-xs">
                <span className="text-slate-600 truncate flex items-center gap-1 font-medium">
                  <span className="material-symbols-outlined text-[15px] text-[#006c4a]">description</span>
                  {vaccineCardUploaded ? 'vet_record_page1.jpg (Uploaded)' : 'No file chosen'}
                </span>
                <label className="py-1 px-3 bg-[#006c4a] text-white rounded-lg text-xs font-bold flex items-center gap-1 cursor-pointer hover:bg-[#005137]">
                  <span className="material-symbols-outlined text-[14px]">file_upload</span>
                  <span>{vaccineCardUploaded ? 'Change / बदला' : 'Upload'}</span>
                  <input
                    type="file"
                    className="hidden"
                    onChange={() => setVaccineCardUploaded(true)}
                  />
                </label>
              </div>
            </div>

            {/* 2. Deworming Record */}
            <div className="p-3 rounded-xl bg-slate-50 border border-slate-200/70 flex flex-col gap-2">
              <div className="flex items-start gap-2">
                <div className="w-8 h-8 rounded-full bg-slate-200 flex items-center justify-center text-[#ff6b35] shrink-0 mt-0.5">
                  <span className="material-symbols-outlined text-[18px]">medication</span>
                </div>
                <div>
                  <p className="text-xs font-bold text-slate-900 leading-tight">
                    Medicines &amp; Deworming Record / जंतनाशक व औषध चिठ्ठी
                  </p>
                  <p className="text-[11px] text-slate-500">Deworming done within the last 30 days &amp; vet prescription</p>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2 pt-1">
                <label className="py-2 px-2.5 bg-white rounded-lg border border-slate-200 hover:border-[#ff6b35] flex items-center justify-center gap-1 text-[#ff6b35] text-xs font-bold cursor-pointer">
                  <span className="material-symbols-outlined text-[16px]">photo_camera</span>
                  <span>Upload Prescription</span>
                  <input type="file" className="hidden" />
                </label>
                <input
                  type="date"
                  value={dewormingDate}
                  onChange={(e) => setDewormingDate(e.target.value)}
                  className="w-full h-9 bg-white rounded-lg px-2 text-slate-800 text-xs border border-slate-200 outline-none"
                />
              </div>
            </div>

            {/* 3. KCI / Breed Certificate */}
            <div className="p-3 rounded-xl bg-slate-50 border border-slate-200/70 flex flex-col gap-2">
              <div className="flex items-start justify-between gap-2">
                <div className="flex items-start gap-2">
                  <div className="w-8 h-8 rounded-full bg-amber-100 flex items-center justify-center text-amber-800 shrink-0 mt-0.5">
                    <span className="material-symbols-outlined text-[18px]">workspace_premium</span>
                  </div>
                  <div>
                    <p className="text-xs font-bold text-slate-900 leading-tight">
                      Breed / KCI Certificates / जात व नोंदणी प्रमाणपत्र
                    </p>
                    <p className="text-[11px] text-slate-500">Kennel Club of India microchip / purebred lineage paper</p>
                  </div>
                </div>
                <span className="text-[10px] bg-amber-100 text-amber-900 px-2 py-0.5 rounded-full font-bold flex items-center gap-1 shrink-0">
                  <span className="material-symbols-outlined text-[12px]">military_tech</span> KCI Verified
                </span>
              </div>

              <label className="w-full py-2 px-3 bg-white hover:bg-slate-100 border border-dashed border-slate-300 rounded-lg flex items-center justify-center gap-2 text-slate-700 text-xs font-bold cursor-pointer">
                <span className="material-symbols-outlined text-[#ff6b35] text-[18px]">upload_file</span>
                <span>{kciUploaded ? 'KCI_Registration_Cert.pdf (Attached)' : 'Upload KCI / Lineage Certificate (PDF/JPG)'}</span>
                <input type="file" className="hidden" onChange={() => setKciUploaded(true)} />
              </label>
            </div>
          </div>
        </section>

        {/* 5. Pricing / Adoption Terms */}
        <section className="px-4 pt-4">
          <div className="bg-white rounded-2xl p-4 shadow-xs border border-slate-100 space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-sm font-bold font-heading text-slate-900">
                  {listingType === 'sell' ? 'Listing Price / अपेक्षित किंमत' : 'Adoption Commitment / मोफत दत्तक नियम'}
                </h2>
                <p className="text-xs text-slate-400">
                  {listingType === 'sell' ? 'Set realistic price for faster transactions' : 'Thank you for giving this pet a safe home'}
                </p>
              </div>
              <span className="material-symbols-outlined text-[#ff6b35] text-[24px]">
                {listingType === 'sell' ? 'currency_rupee' : 'volunteer_activism'}
              </span>
            </div>

            {listingType === 'sell' ? (
              <div className="space-y-2">
                <div className="relative">
                  <span className="absolute left-3.5 top-2.5 text-xl font-bold text-[#ff6b35]">₹</span>
                  <input
                    type="number"
                    value={price}
                    onChange={(e) => setPrice(e.target.value)}
                    placeholder="12,000"
                    className="w-full h-12 pl-8 pr-4 bg-slate-50 border border-slate-200 rounded-xl text-lg font-bold text-slate-900 outline-none focus:border-[#ff6b35]"
                  />
                </div>
                <div className="flex items-center justify-between text-xs text-slate-600">
                  <label className="flex items-center gap-2 cursor-pointer font-medium">
                    <input
                      type="checkbox"
                      checked={isNegotiable}
                      onChange={(e) => setIsNegotiable(e.target.checked)}
                      className="w-4 h-4 rounded accent-[#ff6b35]"
                    />
                    <span>Price Negotiable / वाटाघाटी शक्य</span>
                  </label>
                  <span className="text-[11px] text-slate-400">Fair Sangli market avg: ₹10k–14k</span>
                </div>
              </div>
            ) : (
              <div className="p-3.5 rounded-xl bg-red-50 border border-red-100 space-y-2">
                <div className="flex items-center gap-2 text-[#ba1a1a]">
                  <span className="material-symbols-outlined text-[20px]">favorite</span>
                  <p className="text-xs font-bold">Zero Adoption Fee / १००% मोफत दत्तक</p>
                </div>
                <p className="text-xs text-slate-600">
                  You are posting this pet for ethical adoption. Charging illegal adoption fees is strictly prohibited on PetSathi Sangli.
                </p>
                <div className="flex items-center gap-1.5 text-xs text-slate-700 font-semibold">
                  <span className="material-symbols-outlined text-[15px] text-[#006c4a]">check_circle</span>
                  <span>Home-visit screening rights reserved for pet parent</span>
                </div>
              </div>
            )}
          </div>
        </section>

        {/* 6. Sangli Location & Contact */}
        <section className="px-4 pt-4">
          <div className="bg-white rounded-2xl p-4 shadow-xs border border-slate-100 space-y-3">
            <div>
              <h2 className="text-sm font-bold font-heading text-slate-900">
                Location &amp; Contact <span className="text-xs text-slate-500 font-normal">/ पत्ता व संपर्क</span>
              </h2>
              <p className="text-xs text-slate-400">Locals prefer meeting nearby pet owners in Sangli</p>
            </div>

            {/* Locality Dropdown */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1" htmlFor="locality-select">
                Sangli Locality / सांगली परिसर *
              </label>
              <div className="relative">
                <span className="absolute left-3 top-3 text-[#006c4a] material-symbols-outlined text-[18px]">
                  location_on
                </span>
                <select
                  id="locality-select"
                  value={locality}
                  onChange={(e) => setLocality(e.target.value)}
                  className="w-full h-11 bg-slate-50 border border-slate-200 rounded-xl pl-9 pr-8 appearance-none text-xs text-slate-900 outline-none focus:border-[#ff6b35]"
                >
                  {SANGLI_LOCALITIES.map((loc) => (
                    <option key={loc.value} value={loc.value}>
                      {loc.labelEn} ({loc.labelMr})
                    </option>
                  ))}
                </select>
                <span className="absolute right-3 top-3 material-symbols-outlined text-slate-400 pointer-events-none text-[20px]">
                  expand_more
                </span>
              </div>
            </div>

            {/* Description Notes */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1" htmlFor="pet-notes">
                Pet Temperament &amp; Habits / स्वभाव व इतर माहिती
              </label>
              <textarea
                id="pet-notes"
                rows={3}
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="Friendly with kids, potty trained, active and playful... (मुलांशी मैत्रीपूर्ण, खेळकर...)"
                className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 outline-none focus:border-[#ff6b35] resize-none"
              />
            </div>

            {/* Contact Preference */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-2">
                Preferred Contact Method / संपर्क माध्यम
              </label>
              <div className="grid grid-cols-2 gap-2">
                <label className="p-2.5 rounded-xl bg-slate-50 border border-slate-200 flex items-center gap-2 cursor-pointer hover:bg-slate-100">
                  <input
                    type="radio"
                    name="contact_pref"
                    value="call_wa"
                    checked={contactPref === 'call_wa'}
                    onChange={() => setContactPref('call_wa')}
                    className="w-4 h-4 accent-[#ff6b35]"
                  />
                  <div>
                    <p className="text-xs font-bold text-slate-800 leading-tight">Call &amp; WhatsApp</p>
                    <p className="text-[10px] text-slate-500">फोन व व्हॉट्सॲप</p>
                  </div>
                </label>

                <label className="p-2.5 rounded-xl bg-slate-50 border border-slate-200 flex items-center gap-2 cursor-pointer hover:bg-slate-100">
                  <input
                    type="radio"
                    name="contact_pref"
                    value="chat_only"
                    checked={contactPref === 'chat_only'}
                    onChange={() => setContactPref('chat_only')}
                    className="w-4 h-4 accent-[#ff6b35]"
                  />
                  <div>
                    <p className="text-xs font-bold text-slate-800 leading-tight">In-App Chat Only</p>
                    <p className="text-[10px] text-slate-500">फक्त ॲपवर चॅट</p>
                  </div>
                </label>
              </div>
            </div>
          </div>
        </section>

        {/* 7. Fixed Bottom Ergonomic Submit Bar */}
        <div className="fixed bottom-0 inset-x-0 bg-white/95 backdrop-blur-lg border-t border-slate-200/80 shadow-[0_-8px_24px_rgba(19,27,46,0.08)] px-4 py-3 z-40 max-w-lg mx-auto">
          {/* Legal / Ethical Guarantee snippet */}
          <div className="flex items-center justify-between text-slate-500 px-1 mb-2 text-[11px]">
            <span className="flex items-center gap-1.5">
              <span className="material-symbols-outlined text-[15px] text-[#006c4a]" style={{ fontVariationSettings: "'FILL' 1" }}>
                shield
              </span>
              Ethical Care Pledge • काळजी घेण्याचे वचन
            </span>
            <span className="font-bold text-[#ff6b35] flex items-center gap-1">
              <span className="material-symbols-outlined text-[14px]">bolt</span> Live in 15 mins
            </span>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => alert(`Previewing ${petName}: All 4 photo angles, vet documents & price (₹${price}) verified!`)}
              className="w-12 h-12 rounded-xl bg-slate-100 flex items-center justify-center text-slate-700 hover:bg-slate-200 active:scale-95 transition-all"
              title="Preview Listing / पूर्वावलोकन"
            >
              <span className="material-symbols-outlined text-[20px]">visibility</span>
            </button>

            <button
              type="submit"
              disabled={isSubmitting}
              className="flex-1 h-12 rounded-xl bg-[#ff6b35] hover:bg-[#ab3500] text-white font-bold font-heading text-sm shadow-md shadow-[#ff6b35]/30 flex items-center justify-center gap-2 transition-all active:scale-98 disabled:opacity-80"
            >
              {isSubmitting ? (
                <>
                  <span className="material-symbols-outlined text-[20px] animate-spin">
                    progress_activity
                  </span>
                  <span>Publishing / नोंदणी सुरू आहे...</span>
                </>
              ) : submittedMessage ? (
                <>
                  <span className="material-symbols-outlined text-[20px]">check_circle</span>
                  <span>Submitted! / पडताळणीसाठी पाठवले</span>
                </>
              ) : (
                <>
                  <span className="material-symbols-outlined text-[20px]">publish</span>
                  <span>Publish Pet Listing / जाहिरात द्या 🐾</span>
                </>
              )}
            </button>
          </div>
        </div>
      </form>
    </div>
  );
};
